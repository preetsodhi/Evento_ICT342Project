﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Web;

namespace WebService
{
    public class Common
    {
        public static SqlConnection CreateDatabaseConnection(string sConnectionString)
        {
            SqlConnection objSqlConnection = null;
            try
            {
                objSqlConnection = new SqlConnection(sConnectionString);
                if (objSqlConnection.State == ConnectionState.Closed)
                {
                    objSqlConnection.Open();
                }
            }
            catch (Exception ex)
            {
                objSqlConnection = null;
                throw ex;

            }
            return objSqlConnection;
        }
        public static void CloseDatabaseConnection(SqlConnection objConnection)
        {
            try
            {
                if (objConnection.State == ConnectionState.Open || objConnection.State == ConnectionState.Connecting || objConnection.State == ConnectionState.Broken || objConnection.State == ConnectionState.Executing || objConnection.State == ConnectionState.Fetching)
                {
                    objConnection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public class Helpers
        {
            public static bool CheckDataSet(DataSet ds)
            {
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    return true;
                }
                return false;
            }
            public static Object DynamicList(DataSet ds, int tblIdx)
            {
                Object obj = ds.Tables[tblIdx].AsEnumerable().ToList();
                return obj;
            }
        }
        public static void CloseDatabaseConnection(SqlConnection objConnection, SqlTransaction objSqlTransaction)
        {
            try
            {
                if (objConnection.State == ConnectionState.Open || objConnection.State == ConnectionState.Connecting || objConnection.State == ConnectionState.Broken || objConnection.State == ConnectionState.Executing || objConnection.State == ConnectionState.Fetching)
                {
                    objConnection.Close();
                }
                if (objSqlTransaction.Connection.State == ConnectionState.Open || objSqlTransaction.Connection.State == ConnectionState.Connecting || objSqlTransaction.Connection.State == ConnectionState.Broken || objSqlTransaction.Connection.State == ConnectionState.Executing || objSqlTransaction.Connection.State == ConnectionState.Fetching)
                {
                    objSqlTransaction.Dispose();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
    public static class Translator
    {
        internal static To Translate<From, To>(From fromObj)
        {
            Type fromType = typeof(From);
            Type toType = typeof(To);
            To obj = (To)Activator.CreateInstance(toType);
            if (fromType.IsClass && toType.IsClass)
            {
                foreach (PropertyInfo item in fromType.GetProperties())
                {
                    if (obj.GetType().GetProperty(item.Name) != null)
                        obj.GetType().GetProperty(item.Name).SetValue(obj, item.GetValue(fromObj, null), null);
                }
            }
            return (To)obj;
        }
        internal static List<To> Translate<From, To>(List<From> fromList)
        {
            List<To> toRet = null;
            if (fromList != null && fromList.Count > 0)
            {
                toRet = new List<To>();
                foreach (From item in fromList)
                {
                    toRet.Add(Translator.Translate<From, To>(item));
                }
            }
            return toRet;
        }
        internal static To Translate<To>(DataSet ds, int TblIdx, int RowIdx)
        {
            DataRow dr = ds.Tables[TblIdx].Rows[RowIdx];
            DataColumnCollection columns = dr.Table.Columns;
            Type toType = typeof(To);
            To obj = (To)Activator.CreateInstance(toType);
            if (toType.IsClass)
            {
                PropertyInfo pi = null;
                foreach (DataColumn col in columns)
                {
                    pi = obj.GetType().GetProperty(col.ColumnName);
                    if (pi != null)
                        pi.SetValue(obj, !dr.IsNull(col) ? dr[col] : null, null);
                }
            }
            return obj;
        }
        //
        // Summary:
        //     Gets an object of type represented by "To" after populating the values from the DataRow
        //
        // Returns:
        //     An object of the type represented by "To".
        internal static To Translate<To>(DataRow dr)
        {
            DataColumnCollection columns = dr.Table.Columns;
            Type toType = typeof(To);
            To obj = (To)Activator.CreateInstance(toType);
            if (toType.IsClass)
            {
                PropertyInfo pi = null;
                foreach (DataColumn col in columns)
                {

                    pi = obj.GetType().GetProperty(col.ColumnName);
                    if (pi != null)
                    {
                        if (col.ColumnName == "Notice_Content_Eng" || col.ColumnName == "Notice_Content_Hin")
                            pi.SetValue(obj, !dr.IsNull(col) ? HttpUtility.HtmlDecode(dr[col].ToString()) : null, null);

                        else
                            pi.SetValue(obj, !dr.IsNull(col) ? dr[col] : null, null);
                    }

                }

            }
            return obj;

        }

        //
        // Summary:
        //     Gets a System.Collections.Generic.List of type represented by "To" after populating the values from the DataSet.
        //
        // Returns:
        //     A System.Collections.Generic.List of type represented by "To".
        internal static List<To> Translate<To>(DataSet ds, int tableIdx = 0)
        {
            Type toType = typeof(To);
            List<To> toRet = new List<To>();
            if (toType.IsClass)
            {
                foreach (DataRow dr in ds.Tables[tableIdx].Rows)
                {
                    toRet.Add(Translate<To>(dr));
                }
            }
            return toRet;
        }


        //internal static To Translate<To>(DataRow dr, List<Dynamic_Properties> lst)
        //{
        //    DataColumnCollection columns = dr.Table.Columns;
        //    Type toType = typeof(To);
        //    To obj = (To)Activator.CreateInstance(toType);
        //    Dynamic_Properties objPV = new Dynamic_Properties();
        //    if (toType.IsClass)
        //    {
        //        PropertyInfo pi = null;
        //        foreach (DataColumn col in columns)
        //        {
        //            pi = obj.GetType().GetProperty(col.ColumnName);
        //            if (pi != null)
        //                pi.SetValue(obj, !dr.IsNull(col) ? dr[col] : null, null);
        //            else
        //            {
        //                for (int i = 0; i < lst.Count; i++)
        //                {
        //                    if (lst[i].Column_Name == col.ColumnName)
        //                    {
        //                        lst[i].Column_Value = dr[col].ToString();
        //                    }
        //                }
        //            }
        //        }
        //        Type t = obj.GetType();
        //        PropertyInfo[] prop = t.GetProperties();
        //        for (int i = 0; i < prop.Length; i++)
        //        {
        //            if (((prop[i].PropertyType).UnderlyingSystemType).FullName.Contains("Nagar_Nigam_BAL.Dynamic_Properties")) //typeof(List<PivotValue>)   System.Collections.Generic.List`1[[Testing_Logic.PivotValue, Testing Logic, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null]]
        //            {
        //                pi = obj.GetType().GetProperty("lstDynamic");
        //                pi.SetValue(obj, lst, null);
        //            }
        //        }
        //    }
        //    return obj;

        //}


        //internal static List<To> Translate<To>(DataSet ds, Object objBaseClass, int tableIdx = 0)
        //{
        //    List<Dynamic_Properties> lst = new List<Dynamic_Properties>();
        //    List<Dynamic_Properties> lstTemp = null;
        //    Dynamic_Properties objPV = null;
        //    for (int i = 0; i < ds.Tables[0].Columns.Count; i++)
        //    {
        //        objPV = new Dynamic_Properties();
        //        objPV.Column_Name = ds.Tables[0].Columns[i].ToString();
        //        if (objBaseClass.GetType().GetProperty(objPV.Column_Name) == null)
        //            lst.Add(objPV);
        //    }

        //    Type toType = typeof(To);
        //    List<To> toRet = new List<To>();
        //    if (toType.IsClass)
        //    {
        //        foreach (DataRow dr in ds.Tables[tableIdx].Rows)
        //        {
        //            lstTemp = new List<Dynamic_Properties>();
        //            for (int i = 0; i < lst.Count; i++)
        //            {
        //                objPV = new Dynamic_Properties();
        //                objPV.Column_Name = lst[i].Column_Name;
        //                lstTemp.Add(objPV);
        //            }
        //            toRet.Add(Translate<To>(dr, lstTemp));
        //        }
        //    }
        //    return toRet;
        //}
    }
}