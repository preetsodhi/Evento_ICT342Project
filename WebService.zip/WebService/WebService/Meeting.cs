﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebService
{
    public class Meeting 
    {
        public string Meeting_Name { get; set; }
        public string Meeting_Title { get; set; }
        public string Meeting_Type { get; set; }
        public string Meeting_Description { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime End_Date { get; set; }
        public string Start_Time { get; set; }
        public string End_Time { get; set; }
        public string Country { get; set; }
        public string City { get; set; }
        public string District { get; set; }
        public string Street_Address { get; set; }
        public int T_Meeting_Id { get; set; }
        public int T_Person_Detail_Id { get; set; }

    }

}
