﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace WebService
{
    /// <summary>
    /// Summary description for AndroidWebService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]

    public class AndroidWebService : System.Web.Services.WebService
    {
        private SqlConnection con = null;
        private readonly object Event_Title;

        public AndroidWebService()
        {
            con = new SqlConnection();
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

            con = Common.CreateDatabaseConnection(ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString);

        }

        [WebMethod]

        public int SignUp(string PersonFirstName, string PersonLastName, string phoneNo, string Email, string Dob,
                             string Gender, string address, string Username, string password,
                            // string degree, string institute, string Board_univ, string gradeDivision, string passingYear, 
                             string ProfQual,string Company)
        {
            int result = 0;
           

            try
            {
                if (con != null)
                {
                    using (SqlCommand objCommand = new SqlCommand("USP_Insert_User_Registration", con))
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Add("@PersonFirstName", SqlDbType.VarChar).Value = PersonFirstName;
                        objCommand.Parameters.Add("@PersonLastName", SqlDbType.VarChar).Value = PersonLastName;
                        objCommand.Parameters.Add("@phoneNo", SqlDbType.VarChar).Value = phoneNo;
                        objCommand.Parameters.Add("@Email", SqlDbType.VarChar).Value = Email;
                        objCommand.Parameters.Add("@Dob", SqlDbType.VarChar).Value = Dob;
                        objCommand.Parameters.Add("@Gender", SqlDbType.VarChar).Value = Gender;
                        objCommand.Parameters.Add("@address", SqlDbType.VarChar).Value = address;
                        objCommand.Parameters.Add("@Username", SqlDbType.VarChar).Value = Username;
                        objCommand.Parameters.Add("@password", SqlDbType.VarChar).Value = password;
                        //objCommand.Parameters.Add("@degree", SqlDbType.VarChar).Value = degree;
                        //objCommand.Parameters.Add("@institute", SqlDbType.VarChar).Value = institute;
                        //objCommand.Parameters.Add("@Board_univ", SqlDbType.VarChar).Value = Board_univ;
                        //objCommand.Parameters.Add("@gradeDivision", SqlDbType.VarChar).Value = gradeDivision;
                        //objCommand.Parameters.Add("@passingYear", SqlDbType.VarChar).Value = passingYear;
                        objCommand.Parameters.Add("@ProfQual", SqlDbType.VarChar).Value = ProfQual;
                        objCommand.Parameters.Add("@Company", SqlDbType.VarChar).Value = Company;
                        objCommand.Parameters.Add("@Sp_Type",SqlDbType.Int).Value = 1;
                        result = Convert.ToInt32(objCommand.ExecuteNonQuery());

                    }
                }
              
            }
            catch (Exception ex)
            {
                result = 0;
                throw ex;

            }
            finally
            {
                Common.CloseDatabaseConnection(con);
            }
            return result;
        }
        [WebMethod]

        public int Login(string Phone_Number, string Password)
        {
            int _result = 0;

            try
            {
                if (con != null)
                {
                    using (SqlCommand objCommand = new SqlCommand("USP_Person_Login", con))
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Add("@Phone_Number", SqlDbType.VarChar).Value = Phone_Number;
                        objCommand.Parameters.Add("@Person_Password", SqlDbType.VarChar).Value = Password;
                        _result = Convert.ToInt32(objCommand.ExecuteScalar());
                    }
                }

            }
            catch (Exception ex)
            {
                _result = 0;
                throw ex;
            }
            finally
            {
                Common.CloseDatabaseConnection(con);
            }
            return _result;
        }


        [WebMethod]

        public int forgotpassword(string Phone_Number, string Password)
        {
            int _result =0;

            try
            {
                if (con != null)
                {
                    using (SqlCommand objCommand = new SqlCommand("USP_Forget_Password", con))
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Add("@Phone_Number", SqlDbType.VarChar).Value = Phone_Number;
                        objCommand.Parameters.Add("@Password", SqlDbType.VarChar).Value = Password;
                        _result = Convert.ToInt32(objCommand.ExecuteNonQuery());
                    }
                }

            }
            catch (Exception ex)
            {
                _result = 0;
                throw ex;
            }
            finally
            {
                Common.CloseDatabaseConnection(con);
            }
            return _result;
        }

        [WebMethod]
        public int PersonUpdate(PersonDetail item)
        {
            int result = 0;

            try
            {
                if (con != null)
                {
                    using (SqlCommand objCommand = new SqlCommand("USP_Tbl_Person_Detail", con))
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Add("@Person_First_Name", SqlDbType.VarChar).Value = item.Person_First_Name;
                        objCommand.Parameters.Add("@Person_Last_Name", SqlDbType.VarChar).Value = item.Person_Last_Name;
                        objCommand.Parameters.Add("@Date_Of_Birth", SqlDbType.VarChar).Value = item.Date_Of_Birth;
                        objCommand.Parameters.Add("@Gender", SqlDbType.VarChar).Value = item.Gender;
                        objCommand.Parameters.Add("@Address", SqlDbType.VarChar).Value = item.Address;
                        objCommand.Parameters.Add("@Email_Id", SqlDbType.VarChar).Value = item.Email_Id;
                        objCommand.Parameters.Add("@Phone_Number", SqlDbType.VarChar).Value = item.Phone_Number;
                        objCommand.Parameters.Add("@Username", SqlDbType.VarChar).Value = item.Username;
                        objCommand.Parameters.Add("@Password", SqlDbType.VarChar).Value = item.Password;
                        objCommand.Parameters.Add("@Degree", SqlDbType.VarChar).Value = item.Degree;
                        objCommand.Parameters.Add("@Institute_Name", SqlDbType.VarChar).Value = item.Institute_Name;
                        objCommand.Parameters.Add("@Board_University", SqlDbType.VarChar).Value = item.Board_University;
                        objCommand.Parameters.Add("@Grade_Division", SqlDbType.VarChar).Value = item.Grade_Division;
                        objCommand.Parameters.Add("@Professional_Qualification", SqlDbType.VarChar).Value = item.Professional_Qualification;
                        objCommand.Parameters.Add("@Working_Company_Job", SqlDbType.VarChar).Value = item.Working_Company_Job;

                    }
                }

            }
            catch (Exception ex)
            {
                result = 4;
                throw ex;

            }
            finally
            {
                Common.CloseDatabaseConnection(con);
            }
            return result;
        }
        [WebMethod]

        public int EventInsert(string Name, string Title, int EventCategoryID, string Description, string StartDate, string EndDate, string StartTime, string EndTime, string LocationCountry, string LocationCity, string LocationDistrict, string LocationStreet, int PersonID)
        {
            int result = 0;

            try
            {
                if (con != null)
                {
                    using (SqlCommand objCommand = new SqlCommand("USP_Tbl_Event_Detail", con))
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Add("@Name", SqlDbType.VarChar).Value = Name;
                        objCommand.Parameters.Add("@Title", SqlDbType.VarChar).Value = Title;
                        objCommand.Parameters.Add("@EventCategoryID", SqlDbType.Int).Value = EventCategoryID;
                        objCommand.Parameters.Add("@Description", SqlDbType.VarChar).Value = Description;
                        objCommand.Parameters.Add("@Start_Date", SqlDbType.VarChar).Value = StartDate;
                        objCommand.Parameters.Add("@end_Date", SqlDbType.VarChar).Value = EndDate;
                        objCommand.Parameters.Add("@Start_Time", SqlDbType.VarChar).Value = StartTime;
                        objCommand.Parameters.Add("@End_Time", SqlDbType.VarChar).Value = EndTime;
                        objCommand.Parameters.Add("@Country", SqlDbType.VarChar).Value = LocationCountry;
                        objCommand.Parameters.Add("@City", SqlDbType.VarChar).Value = LocationCity;
                        objCommand.Parameters.Add("@District", SqlDbType.VarChar).Value = LocationDistrict;
                        objCommand.Parameters.Add("@locationStreet", SqlDbType.VarChar).Value = LocationStreet;
                        objCommand.Parameters.Add("@personid", SqlDbType.Int).Value = PersonID;
                        objCommand.Parameters.Add("@Sp_Type", SqlDbType.Int).Value = 1;
                        result = Convert.ToInt32(objCommand.ExecuteNonQuery());

                    }
                }

            }
            catch (Exception ex)
            {
                result = 4;
                throw ex;

            }
            finally
            {
                Common.CloseDatabaseConnection(con);
            }
            return result;
        }
        [WebMethod]

        public int EventUpdate(int T_Event_Id, string Name, string Title, int EventCategoryID, string Description, string StartDate, string EndDate, string StartTime, string EndTime, string LocationCountry, string LocationCity, string LocationDistrict, string LocationStreet, int PersonID)
        {
            int result = 0;

            try
            {
                if (con != null)
                {
                    using (SqlCommand objCommand = new SqlCommand("USP_Tbl_Event_Detail", con))
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Add("@T_Event_Id", SqlDbType.VarChar).Value = T_Event_Id;
                        objCommand.Parameters.Add("@Name", SqlDbType.VarChar).Value = Name;
                        objCommand.Parameters.Add("@Title", SqlDbType.VarChar).Value = Title;
                        objCommand.Parameters.Add("@EventCategoryID", SqlDbType.Int).Value = EventCategoryID;
                        objCommand.Parameters.Add("@Description", SqlDbType.VarChar).Value = Description;
                        objCommand.Parameters.Add("@Start_Date", SqlDbType.VarChar).Value = StartDate;
                        objCommand.Parameters.Add("@end_Date", SqlDbType.VarChar).Value = EndDate;
                        objCommand.Parameters.Add("@Start_Time", SqlDbType.VarChar).Value = StartTime;
                        objCommand.Parameters.Add("@End_Time", SqlDbType.VarChar).Value = EndTime;
                        objCommand.Parameters.Add("@Country", SqlDbType.VarChar).Value = LocationCountry;
                        objCommand.Parameters.Add("@City", SqlDbType.VarChar).Value = LocationCity;
                        objCommand.Parameters.Add("@District", SqlDbType.VarChar).Value = LocationDistrict;
                        objCommand.Parameters.Add("@locationStreet", SqlDbType.VarChar).Value = LocationStreet;
                        objCommand.Parameters.Add("@personid", SqlDbType.Int).Value = PersonID;
                        objCommand.Parameters.Add("@Sp_Type", SqlDbType.Int).Value = 2;
                        result = Convert.ToInt32(objCommand.ExecuteNonQuery());

                    }
                }

            }
            catch (Exception ex)
            {
                result = 4;
                throw ex;

            }
            finally
            {
                Common.CloseDatabaseConnection(con);
            }
            return result;
        }

        [WebMethod]
        public string GetAllEvents(int T_Person_Detail_Id)
        {
            List<Event> lst = null;
            DataSet dsResult = null;
            string strResult = string.Empty;

            try
            {
                if (con != null)
                {
                    using (SqlCommand objCommand = new SqlCommand("USP_Get_Event", con))
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Add("@T_Person_Detail_Id", SqlDbType.Int).Value = T_Person_Detail_Id;
                        using (SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter())
                        {
                            dsResult = new DataSet();
                            objSqlDataAdapter.SelectCommand = objCommand;
                            objSqlDataAdapter.Fill(dsResult);
                        }
                    }
                    if (Common.Helpers.CheckDataSet(dsResult))
                    {
                        lst = new List<Event>();
                        lst = Translator.Translate<Event>(dsResult, 0);
                        strResult = JsonConvert.SerializeObject(lst);
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                Common.CloseDatabaseConnection(con);
            }
            return strResult;
        }
        [WebMethod]
        public string AddMeeting(string name, string title, string category, string description,
                                 string startDate, string endDate, string startTime, string endTime,
                                 string locationCountry, string locationCity, string locationDistrict, string locationStreet,int personid, int M_meetingtype_id)
        {
            string result = null;

            try
            {
                if (con != null)
                {
                    using (SqlCommand objCommand = new SqlCommand("USP_Tbl_Meeting_Detail", con))
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Add("@Meeting_Name", SqlDbType.VarChar).Value = name;
                        objCommand.Parameters.Add("@Meeting_Title", SqlDbType.VarChar).Value = title;
                        objCommand.Parameters.Add("@Meeting_Category", SqlDbType.VarChar).Value = category;
                        objCommand.Parameters.Add("@Meeting_Description", SqlDbType.VarChar).Value = description;
                        objCommand.Parameters.Add("@Start_Date", SqlDbType.VarChar).Value = startDate;
                        objCommand.Parameters.Add("@end_Date", SqlDbType.VarChar).Value = endDate;
                        objCommand.Parameters.Add("@Start_Time", SqlDbType.VarChar).Value = startTime;
                        objCommand.Parameters.Add("@End_Time", SqlDbType.VarChar).Value = endTime;
                        objCommand.Parameters.Add("@Country", SqlDbType.VarChar).Value = locationCountry;
                        objCommand.Parameters.Add("@City", SqlDbType.VarChar).Value = locationCity;
                        objCommand.Parameters.Add("@District", SqlDbType.VarChar).Value = locationDistrict;
                        objCommand.Parameters.Add("@locationStreet", SqlDbType.VarChar).Value = locationStreet;
                        objCommand.Parameters.Add("@personid", SqlDbType.Int).Value = personid;
                        objCommand.Parameters.Add("@M_meetingtype_id", SqlDbType.Int).Value = M_meetingtype_id;
                        objCommand.Parameters.Add("@Sp_Type", SqlDbType.Int).Value = 1;
                        result = Convert.ToString(objCommand.ExecuteScalar());

                    }
                }

            }
            catch (Exception ex)
            {
                result = "";
                throw ex;

            }
            finally
            {
                Common.CloseDatabaseConnection(con);
            }
            return result;
        }
        [WebMethod]
        public string UpdateMeeting(string name, string title, string category, string description,
                                 string startDate, string endDate, string startTime, string endTime,
                                 string locationCountry, string locationCity, string locationDistrict, string locationStreet, int personid, int M_meetingtype_id,int T_Meeting_Id)
        {
            string result = null;

            try
            {
                if (con != null)
                {
                    using (SqlCommand objCommand = new SqlCommand("USP_Tbl_Meeting_Detail", con))
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Add("@T_Meeting_Id", SqlDbType.Int).Value = T_Meeting_Id;
                        objCommand.Parameters.Add("@Meeting_Name", SqlDbType.VarChar).Value = name;
                        objCommand.Parameters.Add("@Meeting_Title", SqlDbType.VarChar).Value = title;
                        objCommand.Parameters.Add("@Meeting_Category", SqlDbType.VarChar).Value = category;
                        objCommand.Parameters.Add("@Meeting_Description", SqlDbType.VarChar).Value = description;
                        objCommand.Parameters.Add("@Start_Date", SqlDbType.VarChar).Value = startDate;
                        objCommand.Parameters.Add("@end_Date", SqlDbType.VarChar).Value = endDate;
                        objCommand.Parameters.Add("@Start_Time", SqlDbType.VarChar).Value = startTime;
                        objCommand.Parameters.Add("@End_Time", SqlDbType.VarChar).Value = endTime;
                        objCommand.Parameters.Add("@Country", SqlDbType.VarChar).Value = locationCountry;
                        objCommand.Parameters.Add("@City", SqlDbType.VarChar).Value = locationCity;
                        objCommand.Parameters.Add("@District", SqlDbType.VarChar).Value = locationDistrict;
                        objCommand.Parameters.Add("@locationStreet", SqlDbType.VarChar).Value = locationStreet;
                        objCommand.Parameters.Add("@personid", SqlDbType.Int).Value = personid;
                        objCommand.Parameters.Add("@M_meetingtype_id", SqlDbType.Int).Value = M_meetingtype_id;
                        objCommand.Parameters.Add("@Sp_Type", SqlDbType.Int).Value = 2;
                        result = Convert.ToString(objCommand.ExecuteScalar());

                    }
                }

            }
            catch (Exception ex)
            {
                result = "";
                throw ex;

            }
            finally
            {
                Common.CloseDatabaseConnection(con);
            }
            return result;
        }
        [WebMethod]
        public string GetAllMeeting(int T_Person_Detail_Id)
        {
            List<Meeting> lst = null;
            DataSet dsResult = null;
            string strResult = string.Empty;

            try
            {
                if (con != null)
                {
                    using (SqlCommand objCommand = new SqlCommand("USP_Get_Tbl_Meeting_Detail", con))
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Add("@T_Person_Detail_Id", SqlDbType.Int).Value = T_Person_Detail_Id;
                        using (SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter())
                        {
                            dsResult = new DataSet();
                            objSqlDataAdapter.SelectCommand = objCommand;
                            objSqlDataAdapter.Fill(dsResult);
                        }
                    }
                    if (Common.Helpers.CheckDataSet(dsResult))
                    {
                        lst = new List<Meeting>();
                        lst = Translator.Translate<Meeting>(dsResult, 0);
                        strResult = JsonConvert.SerializeObject(lst);
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                Common.CloseDatabaseConnection(con);
            }
            return strResult;
        }

        [WebMethod]
        public string GetMeetingCategory()
        {
            List<Event> lst = null;
            DataSet dsResult = null;
            string strResult = string.Empty;

            try
            {
                if (con != null)
                {
                    using (SqlCommand objCommand = new SqlCommand("USP_Get_Meeting_Category", con))
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter())
                        {
                            dsResult = new DataSet();
                            objSqlDataAdapter.SelectCommand = objCommand;
                            objSqlDataAdapter.Fill(dsResult);
                        }
                    }
                    if (Common.Helpers.CheckDataSet(dsResult))
                    {
                        lst = new List<Event>();
                        lst = Translator.Translate<Event>(dsResult, 0);
                        strResult = JsonConvert.SerializeObject(lst);
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                Common.CloseDatabaseConnection(con);
            }
            return strResult;
        }
        [WebMethod]
        public string GetEventCategory()
        {
            List<Event> lst = null;
            DataSet dsResult = null;
            string strResult = string.Empty;

            try
            {
                if (con != null)
                {
                    using (SqlCommand objCommand = new SqlCommand("USP_Get_Event_Category", con))
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;
                        using (SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter())
                        {
                            dsResult = new DataSet();
                            objSqlDataAdapter.SelectCommand = objCommand;
                            objSqlDataAdapter.Fill(dsResult);
                        }
                    }
                    if (Common.Helpers.CheckDataSet(dsResult))
                    {
                        lst = new List<Event>();
                        lst = Translator.Translate<Event>(dsResult, 0);
                        strResult = JsonConvert.SerializeObject(lst);
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                Common.CloseDatabaseConnection(con);
            }
            return strResult;
        }

        [WebMethod]
        public string GetCategoriesWiseEvents(int M_Event_Category_Id)
        {
            List<Event> lst = null;
            DataSet dsResult = null;
            string strResult = string.Empty;

            try
            {
                if (con != null)
                {
                    using (SqlCommand objCommand = new SqlCommand("USP_Get_Category_Wise_Event", con))
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;

                        objCommand.Parameters.Add("@M_Event_Category_Id", SqlDbType.Int).Value = M_Event_Category_Id;
                        using (SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter())
                        {
                            dsResult = new DataSet();
                            objSqlDataAdapter.SelectCommand = objCommand;
                            objSqlDataAdapter.Fill(dsResult);
                        }
                    }
                    if (Common.Helpers.CheckDataSet(dsResult))
                    {
                        lst = new List<Event>();
                        lst = Translator.Translate<Event>(dsResult, 0);
                        strResult = JsonConvert.SerializeObject(lst);
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                Common.CloseDatabaseConnection(con);
            }
            return strResult;
        }
        [WebMethod]
        public string GetMeetingTypeWiseMeeting(int M_Meeting_Type_Id)
        {
            List<Meeting> lst = null;
            DataSet dsResult = null;
            string strResult = string.Empty;

            try
            {
                if (con != null)
                {
                    using (SqlCommand objCommand = new SqlCommand("USP_Get_Category_Wise_Meeting", con))
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;

                        objCommand.Parameters.Add("@M_Meeting_Type_Id", SqlDbType.VarChar).Value = M_Meeting_Type_Id;
                        using (SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter())
                        {
                            dsResult = new DataSet();
                            objSqlDataAdapter.SelectCommand = objCommand;
                            objSqlDataAdapter.Fill(dsResult);
                        }
                    }
                    if (Common.Helpers.CheckDataSet(dsResult))
                    {
                        lst = new List<Meeting>();
                        lst = Translator.Translate<Meeting>(dsResult, 0);
                        strResult = JsonConvert.SerializeObject(lst);
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                Common.CloseDatabaseConnection(con);
            }
            return strResult;
        }

        [WebMethod]
        public string GetMeetingbyMeetingId(int T_Meeting_Id)
        {
            List<Meeting> lst = null;
            DataSet dsResult = null;
            string strResult = string.Empty;

            try
            {
                if (con != null)
                {
                    using (SqlCommand objCommand = new SqlCommand("USP_Get_Meeting_by_MeetingId", con))
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;

                        objCommand.Parameters.Add("@T_Meeting_Id", SqlDbType.VarChar).Value = T_Meeting_Id;
                        using (SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter())
                        {
                            dsResult = new DataSet();
                            objSqlDataAdapter.SelectCommand = objCommand;
                            objSqlDataAdapter.Fill(dsResult);
                        }
                    }
                    if (Common.Helpers.CheckDataSet(dsResult))
                    {
                        lst = new List<Meeting>();
                        lst = Translator.Translate<Meeting>(dsResult, 0);
                        strResult = JsonConvert.SerializeObject(lst);
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                Common.CloseDatabaseConnection(con);
            }
            return strResult;
        }

        [WebMethod]
        public int DeleteEvent(int T_Event_Id)
        {
            int result = 0;

            try
            {
                if (con != null)
                {
                    using (SqlCommand objCommand = new SqlCommand("USP_Delete_Event", con))
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Add("@T_Event_Id", SqlDbType.VarChar).Value = T_Event_Id;
                        result = Convert.ToInt32(objCommand.ExecuteNonQuery());

                    }
                }

            }
            catch (Exception ex)
            {
                result = 4;
                throw ex;

            }
            finally
            {
                Common.CloseDatabaseConnection(con);
            }
            return result;


        }

        [WebMethod]
        public int DeleteMeeting(int T_Meeting_Id)
        {
            int result = 0;

            try
            {
                if (con != null)
                {
                    using (SqlCommand objCommand = new SqlCommand("USP_Delete_Meeting", con))
                    {
                        objCommand.CommandType = CommandType.StoredProcedure;
                        objCommand.Parameters.Add("@T_Meeting_Id", SqlDbType.VarChar).Value = T_Meeting_Id;
                        result = Convert.ToInt32(objCommand.ExecuteNonQuery());

                    }
                }

            }
            catch (Exception ex)
            {
                result = 4;
                throw ex;

            }
            finally
            {
                Common.CloseDatabaseConnection(con);
            }
            return result;


        }

    }
}
