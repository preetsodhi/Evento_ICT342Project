﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebService
{
    public class AllClassDTO
    {
        public int Tbl_Person_Detail_Id { get; set; }
        public string Person_First_Name { get; set; }
        public string Person_Last_Name { get; set; }
        public string Date_Of_Birth { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public string Email_Id { get; set; }
        public string Phone_Number { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Degree { get; set; }
        public string Institute_Name { get; set; }
        public string Board_University { get; set; }
        public string Grade_Division { get; set; }
        public string Passing_Year { get; set; }
        public string Professional_Qualification { get; set; }
        public string Working_Company_Job { get; set; }

    }



}