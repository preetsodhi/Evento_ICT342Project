﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebService
{
    public class Event
    {

        public string Event_Title { get; set; }
        public string Event_Category_Name { get; set; }
        public string Event_Name { get; set; }
        public string Event_Description { get; set; }
        public DateTime Event_Start_Date { get; set; }
        public DateTime Event_End_Date { get; set; }
        public string Event_Start_Time { get; set; }
        public string Event_End_Time { get; set; }
        public string Country { get; set; }
        public string City { get; set; }
        public string District { get; set; }
        public string Street_Address { get; set; }
        public int T_Event_Id { get; set; }

        // Navigation Property


    }
}
