package com.example.myeventmanager.Service;

import com.example.myeventmanager.Event.AddEventFragment;
import com.example.myeventmanager.Event.Event;
import com.example.myeventmanager.Event.EventDTO;
import com.example.myeventmanager.Event.OpenMapEvent;
import com.example.myeventmanager.Event.ShareEvent;
import com.example.myeventmanager.HomeActivity;
import com.example.myeventmanager.HomeFragment;
import com.example.myeventmanager.LoginActivity;
import com.example.myeventmanager.MainActivity;
import com.example.myeventmanager.Meeting.AddMeetingFragment;
import com.example.myeventmanager.Meeting.Meeting;
import com.example.myeventmanager.Meeting.MeetingDTO;
import com.example.myeventmanager.Meeting.OpenMapMeeting;
import com.example.myeventmanager.Meeting.ShareMeeting;
import com.example.myeventmanager.MeetingsFragment;
import com.example.myeventmanager.MyEventsFragment;
import com.example.myeventmanager.RegisterActivity;
import com.example.myeventmanager.ResetPasswordActivity;
import com.example.myeventmanager.UpcomingEventsActivity;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONObject;

public class Caller extends Thread {

    public CallSoap cs;
    public String name,title,description,startDate,endDate,startTime,endTime, locationCountry,
            locationCity,locationDistrict,locationStreet,type,category;

    public int meetingID,meetingTypeID,eventID,eventCategoryID;
    public int personID;

    public String PersonFirstName,PersonLastName, phoneNo,Email,
            DOB,Gender,address,Username,password, degree,institute,
            board_univ,gradeDivision,passingYear,profQual,company;

    public String method,resp;
    public String[] Event_Name, Event_Title,Event_Type,Event_Description,Event_StartDate,
                Event_EndDate,Event_StartTime,Event_EndTime,Event_Country,Event_Suburb,Event_Street;
    public String[] Event_City;
    public String[] Meeting_Name;
    public String[] Meeting_Title;
    public String[] Meeting_Type;
    public String[] Meeting_Description;
    public String[] Meeting_StartDate;
    public String[] Meeting_EndDate;
    public String[] Meeting_StartTime;
    public String[] Meeting_EndTime;
    public String[] Meeting_Country;
    public String[] Meeting_City;
    public String[] Meeting_District;
    public String[] Meeting_Street;
    public int[] Meeting_Id;
    public int Event_Category_Id,MeetingTypeId;
    Event[] events;
    Meeting[] meetings;
    public MeetingDTO[] mDTO;
    public MeetingDTO mDTO2;
    public EventDTO[] eDTO;
    private JSONObject jObj = null;
    Gson gson = new GsonBuilder().serializeNulls().create();

    public void run() {
        try {
            cs = new CallSoap(method);

            if (method.equals("SignUp")) {
                resp = cs.CallSignUp(PersonFirstName,PersonLastName,phoneNo,Email,DOB,Gender,
                        address,Username,password,company);
                RegisterActivity.rslt=resp;
            } else if (method.equals("Login")) {
                resp = cs.CallLogin(phoneNo, password);
                LoginActivity.rslt=resp;
                MainActivity.rslt=resp;}
            else if (method.equals("PersonUpdate")) {
                resp = cs.CallPersonUpdate(personID);
                ResetPasswordActivity.rslt2 = resp;
            }
            else if (method.equals("EventInsert")) {
                resp = cs.CallAddEvent(name, title, eventCategoryID, description, startDate, endDate, startTime, endTime, locationCountry,
                        locationCity, locationDistrict, locationStreet,personID);
                AddEventFragment.rslt = resp;
            }
            else if (method.equals("EventUpdate")) {
                resp = cs.CallUpdateEvent(eventID,name, title, eventCategoryID, description, startDate, endDate, startTime, endTime, locationCountry,
                        locationCity, locationDistrict, locationStreet,personID);
                AddEventFragment.rslt = resp;
            }
            else if (method.equals("DeleteEvent")) {
                resp = cs.CallDeleteEvent(eventID);
                HomeActivity.rslt = resp;
            }
            else if (method.equals("GetAllEvents")) {
                resp = cs.CallGetAllEvents(personID);

                if(!(resp.equals("anyType{}"))) {
                    eDTO = new EventDTO[]{};
                    eDTO = gson.fromJson(resp, EventDTO[].class);
                    Event_Name = new String[eDTO.length];
                    Meeting_City = new String[eDTO.length];
                    for (int i = 0; i < eDTO.length; i++) {
                        Event_Name[i] = eDTO[i].getEvent_Name();
                        Meeting_City[i] = eDTO[i].getCity();
                    }
                    HomeActivity.rslt = "Success";
                    MyEventsFragment.rslt = "Success";
                }
                else if(resp.equals("anyType{}")){
                    MyEventsFragment.rslt = "NoEvents";
                }
            }
            else if (method.equals("GetEventbyEventId")) {
                resp = cs.CallGetEventById(eventID);

                eDTO = new EventDTO[]{};
                eDTO = gson.fromJson(resp,EventDTO[].class);
                name = eDTO[0].getEvent_Name();
                title = eDTO[0].getEvent_Title();
                category = eDTO[0].getEvent_Category();
                Event_Category_Id = eDTO[0].getM_Event_Category_Id();
                description = eDTO[0].getEvent_Description();
                startDate = eDTO[0].getStart_Date();
                endDate = eDTO[0].getEnd_Date();
                startTime = eDTO[0].getStart_Time();
                endTime = eDTO[0].getEnd_Time();
                locationCountry = eDTO[0].getCountry();
                locationCity = eDTO[0].getCity();
                locationDistrict = eDTO[0].getDistrict();
                locationStreet = eDTO[0].getStreet_Address();
                HomeActivity.rslt = "Success";
                OpenMapEvent.rslt = "Success";
                ShareEvent.rslt = "Success";
                AddEventFragment.rslt = "Success";
            }
            else if (method.equals("AddMeeting")) {
                resp = cs.CallAddMeeting(name, title, meetingTypeID, description, startDate, endDate, startTime, endTime, locationCountry,
                        locationCity, locationDistrict, locationStreet,personID);
                AddMeetingFragment.rslt = resp;
            }
            else if (method.equals("UpdateMeeting")) {
                resp = cs.CallUpdateMeeting(meetingID,name, title, meetingTypeID, description, startDate, endDate, startTime, endTime, locationCountry,
                        locationCity, locationDistrict, locationStreet,personID);
                AddMeetingFragment.rslt = resp;
            }
            else if (method.equals("DeleteMeeting")) {
                resp = cs.CallDeleteMeeting(meetingID);
                HomeActivity.rslt = resp;
            }
            else if (method.equals("GetAllMeeting")) {
                resp = cs.CallGetAllMeeting(personID);

                if(!(resp.equals("anyType{}"))) {
                    mDTO = new MeetingDTO[]{};
                    mDTO = gson.fromJson(resp, MeetingDTO[].class);
                    Meeting_Name = new String[mDTO.length];
                    Meeting_City = new String[mDTO.length];
                    for (int i = 0; i < mDTO.length; i++) {
                        Meeting_Name[i] = mDTO[i].getMeeting_Name();
                        Meeting_City[i] = mDTO[i].getCity();
                    }
                    HomeFragment.rslt = "Success";
                    MeetingsFragment.rslt = "Success";
                }
                else if(resp.equals("anyType{}")){
                    MeetingsFragment.rslt = "NoMeetings";
                }
            }
            else if (method.equals("GetAllUpcomingEvents")) {
                resp = cs.CallGetAllUpcomingEvents();

                eDTO = new EventDTO[]{};
                eDTO = gson.fromJson(resp,EventDTO[].class);
                Event_Name = new String[eDTO.length];
                Event_Title = new String[eDTO.length];
                Event_Type = new String[eDTO.length];
                Event_Description = new String[eDTO.length];
                Event_StartDate = new String[eDTO.length];
                Event_EndDate = new String[eDTO.length];
                Event_StartTime = new String[eDTO.length];
                Event_EndTime = new String[eDTO.length];
                Event_Country = new String[eDTO.length];
                Event_City = new String[eDTO.length];
                Event_Suburb = new String[eDTO.length];
                Event_Street = new String[eDTO.length];
                for(int i = 0;i<eDTO.length;i++) {
                    Event_Name[i] = eDTO[i].getEvent_Name();
                    Event_Title[i] = eDTO[i].getEvent_Title();
                    Event_Type[i] = eDTO[i].getEvent_Category();
                    Event_Description[i] = eDTO[i].getEvent_Description();
                    Event_StartDate[i] = eDTO[i].getStart_Date();
                    Event_EndDate[i] = eDTO[i].getEnd_Date();
                    Event_StartTime[i] = eDTO[i].getStart_Time();
                    Event_EndTime[i] = eDTO[i].getEnd_Time();
                    Event_Country[i] = eDTO[i].getCountry();
                    Event_City[i] = eDTO[i].getCity();
                    Event_Suburb[i] = eDTO[i].getDistrict();
                    Event_Street[i] = eDTO[i].getStreet_Address();
                }
                HomeFragment.rslt = "Success";
                UpcomingEventsActivity.rslt = "Success";
            }
            else if (method.equals("forgotpassword")) {
                resp = cs.Callforgotpassword(phoneNo,password);
                ResetPasswordActivity.rslt=resp;
            }
            else if (method.equals("GetMeetingbyMeetingId")) {
                resp = cs.CallGetMeetingById(meetingID);

                    mDTO = new MeetingDTO[]{};
                    mDTO = gson.fromJson(resp, MeetingDTO[].class);
                    name = mDTO[0].getMeeting_Name();
                    title = mDTO[0].getMeeting_Title();
                    type = mDTO[0].getMeeting_Category();
                    MeetingTypeId = mDTO[0].getM_Meeting_Type_Id();
                    description = mDTO[0].getMeeting_Description();
                    startDate = mDTO[0].getStart_Date();
                    endDate = mDTO[0].getEnd_Date();
                    startTime = mDTO[0].getStart_Time();
                    endTime = mDTO[0].getEnd_Time();
                    locationCountry = mDTO[0].getCountry();
                    locationCity = mDTO[0].getCity();
                    locationDistrict = mDTO[0].getDistrict();
                    locationStreet = mDTO[0].getStreet_Address();
                    HomeActivity.rslt = "Success";
                    OpenMapMeeting.rslt = "Success";
                    ShareMeeting.rslt = "Success";
                    AddMeetingFragment.rslt = "Success";
            }
        } catch (Exception ex) {
            RegisterActivity.rslt=ex.toString();
            LoginActivity.rslt=ex.toString();
            ResetPasswordActivity.rslt=ex.toString();
            MeetingsFragment.rslt=ex.toString();
            AddEventFragment.rslt=ex.toString();
            AddMeetingFragment.rslt = ex.toString();
            HomeActivity.rslt = ex.toString();
        }
    }
}
