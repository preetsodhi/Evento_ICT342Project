package com.example.myeventmanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myeventmanager.Event.AddEventFragment;
import com.example.myeventmanager.Event.EventAdapter;
import com.example.myeventmanager.Event.EventDetailActivity;
import com.example.myeventmanager.Event.OpenMapEvent;
import com.example.myeventmanager.Event.ShareEvent;
import com.example.myeventmanager.Meeting.AddMeetingFragment;
import com.example.myeventmanager.Meeting.MeetingAdapter;
import com.example.myeventmanager.Meeting.MeetingDetailActivity;
import com.example.myeventmanager.Meeting.OpenMapMeeting;
import com.example.myeventmanager.Meeting.ShareMeeting;
import com.example.myeventmanager.Service.Caller;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import io.paperdb.Paper;

import static java.lang.Integer.parseInt;

public class HomeActivity extends AppCompatActivity implements MyEventsFragment.AddNewEventListener, EventAdapter.EditEventListener
        ,MeetingsFragment.AddNewMeetingListener, MeetingAdapter.EditMeetingListener,MeetingAdapter.OpenMapListener,
        EventAdapter.OpenMapListener,EventAdapter.OpenWhatsAppListener,MeetingAdapter.OpenWhatsAppListener
,EventAdapter.DetailEventListener , MeetingAdapter.DeleteMeetingListener, EventAdapter.DeleteEventListener,
MeetingAdapter.OpenMeetingDetailListener{

    private FragmentManager fragmentManager;

    String method;
    public static String rslt="";
    ListView listView1;
    Caller c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        fragmentManager = getSupportFragmentManager();

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnNavigationItemSelectedListener(navListener);

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new HomeFragment()).commit() ;
    }
     @Override
     public boolean onCreateOptionsMenu(Menu menu) {
         MenuInflater inflater = getMenuInflater();
         inflater.inflate(R.menu.top_menu, menu);
         return true;
     }
     @Override
     public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();
         switch (id) {

             case R.id.searchIcon:
                 Toast.makeText(this,"Search Under Construction",Toast.LENGTH_SHORT).show();
                 return true;
             case R.id.logout:
                 Paper.book().destroy();
                 Intent i = new Intent(HomeActivity.this,MainActivity.class);
                 startActivity(i);
                 return true;
             default:
                 return super.onOptionsItemSelected(item);
         }
     }


    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener(){
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item){
                    Fragment selectedFragment = null;

                    switch (item.getItemId()){
                        case R.id.nav_home:
                            selectedFragment = new HomeFragment();
                            break;
                        case R.id.nav_myevents:
                            selectedFragment = new MyEventsFragment();
                            break;
                        case R.id.nav_meetings:
                            selectedFragment = new MeetingsFragment();
                            break;
                        case R.id.nav_nearbyevents:
                            selectedFragment = new NearbyEventsFragment();
                            break;
                    }
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,selectedFragment)
                            .commit();
                    return true;
                }
            };
    @Override
    public void onAddNewEvent() {
        FragmentTransaction ft = fragmentManager.beginTransaction();
        AddEventFragment addEventFragment = new AddEventFragment();
        ft.replace(R.id.fragment_container, addEventFragment);
        ft.addToBackStack(null);
        ft.commit();
    }

    @Override
    public void onComplete() {
        FragmentTransaction ft = fragmentManager.beginTransaction();
        MyEventsFragment eventListFragment = new MyEventsFragment();
        ft.replace(R.id.fragment_container, eventListFragment);
        ft.commit();
    }

    @Override
    public void onEditBtnClicked(int eventID) {
        Bundle bundle = new Bundle();
        bundle.putInt("id", eventID);
        FragmentTransaction ft = fragmentManager.beginTransaction();
        AddEventFragment addEventFragment = new AddEventFragment();
        addEventFragment.setArguments(bundle);
        ft.replace(R.id.fragment_container, addEventFragment);
        ft.addToBackStack(null);
        ft.commit();
    }

    @Override
    public void onEditComplete() {
        FragmentTransaction ft = fragmentManager.beginTransaction();
        MyEventsFragment eventListFragment = new MyEventsFragment();
        ft.replace(R.id.fragment_container, eventListFragment);
        ft.commit();
    }
    @Override
    public void onAddNewMeeting() {
        FragmentTransaction ft = fragmentManager.beginTransaction();
        AddMeetingFragment addMeetingFragment = new AddMeetingFragment();
        ft.replace(R.id.fragment_container, addMeetingFragment);
        ft.addToBackStack(null);
        ft.commit();
    }
    @Override
    public void onCompleteMeeting() {
        FragmentTransaction ft = fragmentManager.beginTransaction();
        MeetingsFragment meetingListFragment = new MeetingsFragment();
        ft.replace(R.id.fragment_container, meetingListFragment);
        ft.commit();
    }

    @Override
    public void onEditBtnClickedMeeting(int meetingID) {
        Bundle bundle = new Bundle();
        bundle.putInt("id", meetingID);
        FragmentTransaction ft = fragmentManager.beginTransaction();
        AddMeetingFragment addMeetingFragment = new AddMeetingFragment();
        addMeetingFragment.setArguments(bundle);
        ft.replace(R.id.fragment_container, addMeetingFragment);
        ft.addToBackStack(null);
        ft.commit();
    }

    @Override
    public void onEditCompleteMeeting() {
        FragmentTransaction ft = fragmentManager.beginTransaction();
        MeetingsFragment meetingListFragment = new MeetingsFragment();
        ft.replace(R.id.fragment_container, meetingListFragment);
        ft.commit();
    }
    @Override
    public void onDeleteBtnClickedMeeting(final int meetingID) {
        Bundle bundle = new Bundle();
        bundle.putInt("id", meetingID);
        new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Are You Sure You Want To Delete This Meeting?")
                .setMessage("The Meeting Deleted Cannot be Restored.")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            rslt = "START";
                            method = "DeleteMeeting";
                            Caller c = new Caller();

                            c.meetingID = meetingID;
                            c.method = method;

                            c.join();
                            c.start();
                            while (rslt == "START") {
                                try {
                                    Thread.sleep(10);
                                } catch (Exception ex) {
                                    Toast.makeText(getApplicationContext(), "Error" + ex.toString(), Toast.LENGTH_SHORT).show();
                                }
                            }

                        } catch (Exception ex) {
                            //ad.setTitle("Error!"); ad.setMessage(ex.toString());
                        }
                        //ad.show();
                        if (parseInt(rslt)>0) {
                            Toast.makeText(getApplicationContext(), "Meeting Deleted Successfully...!!", Toast.LENGTH_SHORT).show();
                            FragmentManager fragmentManager = getSupportFragmentManager();
                            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new MeetingsFragment()).commit() ;
                            //setNotif();
                        } else {
                            Toast.makeText(getApplicationContext(), "OOOPSSS....!! Something Went Wrong.. ", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("No",null)
                .show();

    }

    @Override
    public void onDeleteCompleteMeeting() {

    }
     @Override
     public void onOpenMapBtnClickedMeeting(int meetingID) {
         Intent i= new Intent(HomeActivity.this,OpenMapMeeting.class);
         i.putExtra("meetingid",meetingID);
         startActivity(i);
     }

     @Override
     public void onOpenMapCompleteMeeting() {

     }
     @Override
     public void onOpenMapBtnClickedEvent(int eventID) {
         Intent i= new Intent(HomeActivity.this, OpenMapEvent.class);
         i.putExtra("eventid",eventID);
         startActivity(i);
     }

     @Override
     public void onOpenMapCompleteEvent() {

     }
     @Override
     public void onOpenWBtnClickedEvent(int eventID) {
         Intent i= new Intent(HomeActivity.this, ShareEvent.class);
         i.putExtra("eventid",eventID);
         startActivity(i);
     }
     @Override
     public void onOpenWCompleteEvent() {

     }
     @Override
     public void onOpenWBtnClickedMeeting(int meetingID) {
         Intent i= new Intent(HomeActivity.this, ShareMeeting.class);
         i.putExtra("meetingid",meetingID);
         startActivity(i);
     }
     @Override
     public void onOpenWCompleteMeeting() {

     }

    @Override
    public void onDetailBtnClicked(int eventID) {
        Bundle bundle = new Bundle();
        bundle.putInt("id", eventID);
        Caller c = new Caller();
        try {
            rslt = "START";
            method = "GetEventbyEventId";

            c.eventID = eventID;
            c.method = method;
            c.join(); c.start();
            while (rslt == "START") {
                try {
                    Thread.sleep(10);
                } catch (Exception ex) {
                    Toast.makeText(getApplicationContext(), "Error " + ex.toString(), Toast.LENGTH_SHORT).show();
                }
            }

        } catch (Exception ex) {
            //ad.setTitle("Error!"); ad.setMessage(ex.toString());
        }
        if (rslt.equals("Success")) {
            Intent i = new Intent(HomeActivity.this, EventDetailActivity.class);
            i.putExtra("name",c.name);
            i.putExtra("title",c.title);
            i.putExtra("category",c.category);
            i.putExtra("desc",c.description);
            i.putExtra("startDate",c.startDate);
            i.putExtra("endDate",c.endDate);
            i.putExtra("startTime",c.startTime);
            i.putExtra("endTime",c.endTime);
            i.putExtra("country",c.locationCountry);
            i.putExtra("district",c.locationDistrict);
            i.putExtra("city",c.locationCity);
            i.putExtra("street",c.locationStreet);
            startActivity(i);
        } else
            Toast.makeText(getApplicationContext(), "OOOOPSSS Something went wrong...!!", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onDeleteBtnClickedEvent(final int eventID) {
        Bundle bundle = new Bundle();
        bundle.putInt("id", eventID);
        new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Are You Sure You Want To Delete This Event?")
                .setMessage("The Event Deleted Cannot be Restored.")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        try {
                            rslt = "START";
                            method = "DeleteEvent";
                            Caller c = new Caller();

                            c.eventID = eventID;
                            c.method = method;

                            c.join();
                            c.start();
                            while (rslt == "START") {
                                try {
                                    Thread.sleep(10);
                                } catch (Exception ex) {
                                    Toast.makeText(getApplicationContext(), "Error" + ex.toString(), Toast.LENGTH_SHORT).show();
                                }
                            }

                        } catch (Exception ex) {
                            //ad.setTitle("Error!"); ad.setMessage(ex.toString());
                        }
                        //ad.show();
                        if (parseInt(rslt)>0) {
                            Toast.makeText(getApplicationContext(), "Event Deleted Successfully...!!", Toast.LENGTH_SHORT).show();
                            FragmentManager fragmentManager = getSupportFragmentManager();
                            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new MyEventsFragment()).commit() ;
                            //setNotif();
                        } else {
                            Toast.makeText(getApplicationContext(), "OOOPSSS....!! Something Went Wrong.. ", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("No",null)
                .show();

    }

    @Override
    public void onDeleteCompleteEvent() {

    }
    @Override
    public void onOpenDetailMeetingClicked(int meetingID) {
        Bundle bundle = new Bundle();
        bundle.putInt("id", meetingID);
        c = new Caller();
        try {
            rslt = "START";
            method = "GetMeetingbyMeetingId";

            c.meetingID = meetingID;
            c.method = method;

            c.join();
            c.start();
            while (rslt == "START") {
                try {
                    Thread.sleep(10);
                } catch (Exception ex) {
                    Toast.makeText(getApplicationContext(), "Error" + ex.toString(), Toast.LENGTH_SHORT).show();
                }
            }

        } catch (Exception ex) {
            //ad.setTitle("Error!"); ad.setMessage(ex.toString());
        }
        //ad.show();
        if (rslt.equals("Success")) {
            Intent i = new Intent(HomeActivity.this, MeetingDetailActivity.class);
            i.putExtra("name",c.name);
            i.putExtra("title",c.title);
            i.putExtra("type",c.type);
            i.putExtra("desc",c.description);
            i.putExtra("startDate",c.startDate);
            i.putExtra("endDate",c.endDate);
            i.putExtra("startTime",c.startTime);
            i.putExtra("endTime",c.endTime);
            i.putExtra("country",c.locationCountry);
            i.putExtra("district",c.locationDistrict);
            i.putExtra("city",c.locationCity);
            i.putExtra("street",c.locationStreet);
            startActivity(i);
        } else {
            Toast.makeText(getApplicationContext(), "OOOPSSS....!! Something Went Wrong.. ", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onOpenDetailMeetingComplete() {
    }
}
