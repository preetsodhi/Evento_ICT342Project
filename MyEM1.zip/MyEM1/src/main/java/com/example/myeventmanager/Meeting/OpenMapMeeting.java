package com.example.myeventmanager.Meeting;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;

import com.example.myeventmanager.R;
import com.example.myeventmanager.Service.Caller;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class OpenMapMeeting extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    List<MeetingDTO> meetingList;
    int meetingId;
    MeetingDTO[] meeting;
    MeetingDTO m;
    String addr;
    Caller c;

    public static String rslt="";
    String method;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_open_map_meeting);
        Bundle extras = getIntent().getExtras();
        c = new Caller();
        meetingId = extras.getInt("meetingid");
        meetingList = new ArrayList<>();
        meeting = new MeetingDTO[0];
        m = new MeetingDTO();
        try {
            rslt="START";
            method="GetMeetingbyMeetingId";

            c.meetingID = meetingId;
            c.method = method;

            c.join(); c.start();
            while(rslt=="START") {
                try {
                    Thread.sleep(10);
                }catch(Exception ex) {
                    Toast.makeText(getApplicationContext(), "Error"+ex.toString(), Toast.LENGTH_SHORT).show();
                }
            }

        }catch(Exception ex) {
            //ad.setTitle("Error!"); ad.setMessage(ex.toString());
        }
        if(rslt.equals("Success")) {
            addr = c.locationStreet+ ", "+c.locationCity+", "
                    +c.locationDistrict+", "+c.locationCountry;
        }
        else {
            Toast.makeText(getApplicationContext(), "OOOPSSS....!! Something Went Wrong.. ", Toast.LENGTH_SHORT).show();
        }

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        Uri gmmIntentUri = Uri.parse("geo:0,0?q="+addr);
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        startActivity(mapIntent);
    }
}
