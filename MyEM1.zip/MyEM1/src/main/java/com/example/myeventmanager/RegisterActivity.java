package com.example.myeventmanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myeventmanager.DateAndTimePicker.DOBPickerFragment;
import com.example.myeventmanager.Service.Caller;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import static java.lang.Integer.parseInt;

public class RegisterActivity extends AppCompatActivity {

    public static String rslt="";

    private Button btn_register,verify_OTP;
    private EditText register_firstName, register_lastName, register_username, register_phoneno,
            register_email, register_address, register_password, register_password2, enter_OTP,
            register_company;
    public Spinner genderSpinner;
    private ProgressDialog loadingBar;
    String verificationCode;
    String firstname,lastname,phoneno,email,dob,gender,address,username,
            password,password2,company;
    String method;
    private int genderID;

    FirebaseAuth auth;
    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallback;

    public Button DOBbtn;
    DOBPickerFragment dobPicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);//will hide the title
        getSupportActionBar().hide(); //hide the title bar
        setContentView(R.layout.activity_register);

        btn_register = (Button) findViewById(R.id.register_btn);
        verify_OTP = (Button) findViewById(R.id.verify_OTP_);

        register_firstName = (EditText) findViewById(R.id.register_firstname);
        register_lastName = (EditText) findViewById(R.id.register_lastname);
        register_phoneno = (EditText) findViewById(R.id.register_phoneno);
        register_email = (EditText) findViewById(R.id.register_email);
        DOBbtn = (Button)findViewById(R.id.register_dob);
        genderSpinner = (Spinner) findViewById(R.id.register_gender);
        register_address = (EditText) findViewById(R.id.register_address);
        register_username = (EditText) findViewById(R.id.register_username);
        register_password = (EditText) findViewById(R.id.register_password);
        register_password2 = (EditText) findViewById(R.id.register_password2);
        register_company = (EditText) findViewById(R.id.register_company);
        enter_OTP = (EditText)findViewById(R.id.enter_OTP_);

        auth = FirebaseAuth.getInstance();
        loadingBar = new ProgressDialog(this);

        dobPicker = new DOBPickerFragment();
        dobPicker.DOBbtn = DOBbtn;
        genderSpinner.setSelection(0, true);
        View v = genderSpinner.getSelectedView();
        //((TextView)v).setTextColor(Color.WHITE);
        genderSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                //Change the selected item's text color
                ((TextView) view).setTextColor(Color.WHITE);
                genderID = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
            }
        });
        List<String> spinnerArray =  new ArrayList<String>();
        spinnerArray.add("--Select Your Gender--");
        spinnerArray.add("Male");
        spinnerArray.add("Female");
        spinnerArray.add("Other");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                getApplicationContext(), android.R.layout.simple_spinner_item, spinnerArray);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        genderSpinner.setAdapter(adapter);

        DOBbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dobPicker.show(getSupportFragmentManager(),"DOB Picker");
            }
        });

       mCallback = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            @Override
            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {

            }

            @Override
            public void onVerificationFailed(@NonNull FirebaseException e) {

            }

            @Override
            public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                super.onCodeSent(s, forceResendingToken);
                verificationCode = s;
                Toast.makeText(RegisterActivity.this,"Code sent to your number!!",Toast.LENGTH_SHORT).show();
            }
        };

        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                CreateAccount();
            }
        });
    }

    public void send_sms(View view){

    }
    public void verify(View v){
        String inputcode = enter_OTP.getText().toString();
        if(inputcode.equals(""))
            Toast.makeText(RegisterActivity.this,"Please enter OTP received",Toast.LENGTH_SHORT).show();
        else{

           verifyPhoneNumber(verificationCode,inputcode);

        }

    }

    private void verifyPhoneNumber(String verificationCode, String inputcode) {
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationCode,inputcode);
        signInWithPhone(credential);
    }


    private void signInWithPhone(PhoneAuthCredential credential) {
        auth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()) {
                            loadingBar.setTitle("Create Account");
                            loadingBar.setMessage("Please wait while we are checking the credentials.");
                            loadingBar.setCanceledOnTouchOutside(false);
                            loadingBar.show();
                            validate(firstname,lastname, phoneno, email,dob,
                                    gender,address,username,password, company);
                        }
                    }
                });
    }

    private void CreateAccount() {
        firstname = register_firstName.getText().toString();
        lastname = register_lastName.getText().toString();
        phoneno = register_phoneno.getText().toString();
        email = register_email.getText().toString();
        dob = DOBbtn.getText().toString();
        gender = genderSpinner.getSelectedItem().toString();
        address = register_address.getText().toString();
        username = register_username.getText().toString();
        password = register_password.getText().toString();
        password2 = register_password2.getText().toString();
        company = register_company.getText().toString();

        if(TextUtils.isEmpty(firstname)){
            Toast.makeText(this,"Please Enter Your First Name...",Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(lastname)){
            Toast.makeText(this,"Please Enter Your Last Name...",Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(phoneno)){
            Toast.makeText(this,"Please Enter Your Mobile Number...",Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(email)){
            Toast.makeText(this,"Please Enter Your Email Address...",Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(dob)){
            Toast.makeText(this,"Please Enter Your DOB...",Toast.LENGTH_SHORT).show();
        }
        if(gender.equals("--Select Your Gender--")){
            Toast.makeText(this,"Please Select Your Gender...",Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(address)){
            Toast.makeText(this,"Please Enter Your Complete Address...",Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(username)){
            Toast.makeText(this,"Please Enter Your UserName...",Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(password)){
            Toast.makeText(this,"Please Enter Password...",Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(password2)){
            Toast.makeText(this,"Please ReEnter Password...",Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(company)){
            Toast.makeText(this,"Please Enter Your Company Name...",Toast.LENGTH_SHORT).show();
        }

        else{
            if(!password.equals(password2)){
                Toast.makeText(this,"Error!! Passwords do not Match...",Toast.LENGTH_SHORT).show();
            }
            else {
                ((EditText) findViewById(R.id.enter_OTP_)).setVisibility(View.VISIBLE);
                ((Button) findViewById(R.id.verify_OTP_)).setVisibility(View.VISIBLE);
                register_firstName.setVisibility(View.INVISIBLE);
                register_lastName.setVisibility(View.INVISIBLE);
                register_phoneno.setVisibility(View.INVISIBLE);
                register_email.setVisibility(View.INVISIBLE);
                DOBbtn.setVisibility(View.INVISIBLE);
                genderSpinner.setVisibility(View.INVISIBLE);
                register_address.setVisibility(View.INVISIBLE);
                register_username.setVisibility(View.INVISIBLE);
                register_password.setVisibility(View.INVISIBLE);
                register_password2.setVisibility(View.INVISIBLE);
                register_company.setVisibility(View.INVISIBLE);
                btn_register.setVisibility(View.INVISIBLE);


                PhoneAuthProvider.getInstance().verifyPhoneNumber(
                        phoneno, 60, TimeUnit.SECONDS, this, mCallback
                );
            }
        }

    }

    private void validate(final String firstname,final String lastname,final String phoneno,
                          final String email,final String dob, final String gender, final String address,
                          final String username,final String password, final String company) {

        try {
            rslt="START";
            method="SignUp";
            Caller c=new Caller();

            c.PersonFirstName=firstname;
            c.PersonLastName=lastname;
            c.phoneNo=phoneno;
            c.Email=email;
            c.DOB=dob;
            c.Gender=gender;
            c.address=address;
            c.Username=username;
            c.password=password;
            c.company=company;
            c.method = method;

            c.join(); c.start();
            while(rslt=="START") {
                try {
                    Thread.sleep(10);
                }catch(Exception ex) {
                    Toast.makeText(getApplicationContext(), "Error"+ex.toString(), Toast.LENGTH_SHORT).show();
                }
            }

        }catch(Exception ex) {
            //ad.setTitle("Error!"); ad.setMessage(ex.toString());
        }
        //ad.show();
        if((parseInt(rslt)==1)) {
            Toast.makeText(getApplicationContext(), "Your Account Has Been Created Successfully ", Toast.LENGTH_LONG).show();
            Intent i = new Intent(getApplicationContext(), LoginActivity.class);
            startActivity(i);
            finish();
            loadingBar.dismiss();
        }
        else if(parseInt(rslt)==-1){
            Toast.makeText(getApplicationContext(), "Account With This Mobile No. Already Exists!!", Toast.LENGTH_LONG).show();
            loadingBar.dismiss();
        }
        else{
            Toast.makeText(getApplicationContext(), "OOOPSSS....!! Something Went Wrong.. ", Toast.LENGTH_SHORT).show();
            loadingBar.dismiss();
            }

    }
}
