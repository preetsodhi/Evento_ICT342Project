package com.example.myeventmanager;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.myeventmanager.Meeting.MyAdapter2;

public class MyAdapter3 extends BaseAdapter {
    private String[] Event_Name;
    private String[] Event_Title;
    private String[] Event_Category;
    private String[] Event_Description;
    private String[] Event_StartDate;
    private String[] Event_EndDate;
    private String[] Event_StartTime;
    private String[] Event_EndTime;
    private String[] Event_Country;
    private String[] Event_City;
    private String[] Event_Suburb;
    private String[] Event_Street;

    public Activity context;

    public LayoutInflater inflater;

    public MyAdapter3(Activity context, String[] Event_Name, String[] Event_Title, String[] Event_Category,
                      String[] Event_Description, String[] Event_StartDate,String[] Event_EndDate, String[] Event_StartTime,
                      String[] Event_EndTime, String[] Event_Country,String[] Event_Suburb,String[] Event_City,String[] Event_Street) {

        super();
        this.Event_Name = Event_Name;
        this.Event_Title = Event_Title;
        this.Event_Category = Event_Category;
        this.Event_Description = Event_Description;
        this.Event_StartDate = Event_StartDate;
        this.Event_EndDate = Event_EndDate;
        this.Event_StartTime = Event_StartTime;
        this.Event_EndTime = Event_EndTime;
        this.Event_Country = Event_Country;
        this.Event_Suburb = Event_Suburb;
        this.Event_City = Event_City;
        this.Event_Street = Event_Street;
        this.context = context;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return null;
    }

    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return 0;
    }

    public int getCount() {
        // TODO Auto-generated method stub
        return Event_Name.length;
    }

    public class ViewHolder {

        TextView Event_Name;
        TextView Event_Title;
        TextView Event_Type;
        TextView Event_Description;
        TextView Event_StartDate;
        TextView Event_EndDate;
        TextView Event_StartTime;
        TextView Event_EndTime;
        TextView Event_Country;
        TextView Event_Suburb;
        TextView Event_City;
        TextView Event_Street;
    }

    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;

        if (convertView == null) {
            holder = new MyAdapter3.ViewHolder();
            convertView = inflater.inflate(R.layout.indi_view3, null);

            holder.Event_Name = (TextView) convertView.findViewById(R.id.name);
            holder.Event_Title = (TextView) convertView.findViewById(R.id.title);
            holder.Event_Description = (TextView) convertView.findViewById(R.id.desc);
            holder.Event_Type = (TextView) convertView.findViewById(R.id.type);
            holder.Event_StartDate = (TextView) convertView.findViewById(R.id.startDate);
            holder.Event_EndDate = (TextView) convertView.findViewById(R.id.endDate);
            holder.Event_StartTime = (TextView) convertView.findViewById(R.id.startTime);
            holder.Event_EndTime = (TextView) convertView.findViewById(R.id.endTime);
            holder.Event_Country = (TextView) convertView.findViewById(R.id.country);
            holder.Event_Suburb = (TextView) convertView.findViewById(R.id.suburb);
            holder.Event_City = (TextView) convertView.findViewById(R.id.city);
            holder.Event_Street = (TextView) convertView.findViewById(R.id.street);

            convertView.setTag(holder);
        } else
            holder = (MyAdapter3.ViewHolder) convertView.getTag();
        holder.Event_Name.setText("Name: "+Event_Name[position]);
        holder.Event_Title.setText("Title: "+Event_Title[position]);
        holder.Event_Type.setText("Type: "+Event_Category[position]);
        holder.Event_Description.setText("Description: "+Event_Description[position]);
        holder.Event_StartDate.setText("Start Date: "+Event_StartDate[position]);
        holder.Event_EndDate.setText("End Date: "+Event_EndDate[position]);
        holder.Event_StartTime.setText("Start Time: "+Event_StartTime[position]);
        holder.Event_EndTime.setText("End Time: "+Event_EndTime[position]);
        holder.Event_Country.setText("Country: "+Event_Country[position]);
        holder.Event_Suburb.setText("Suburb: "+Event_Suburb[position]);
        holder.Event_City.setText("City: "+Event_City[position]);
        holder.Event_Street.setText("Street: "+Event_Street[position]);
        return convertView;
    }
}

