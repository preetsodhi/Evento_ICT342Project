package com.example.myeventmanager.Event;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.example.myeventmanager.DateAndTimePicker.EndDatePickerFragment;
import com.example.myeventmanager.DateAndTimePicker.EndTimePickerFragment;
import com.example.myeventmanager.DateAndTimePicker.StartDatePickerFragment;
import com.example.myeventmanager.DateAndTimePicker.StartTimePickerFragment;
import com.example.myeventmanager.MeetingsFragment;
import com.example.myeventmanager.MyEventsFragment;
import com.example.myeventmanager.Prevalent.prevalent;
import com.example.myeventmanager.R;
import com.example.myeventmanager.Service.Caller;

import java.util.ArrayList;
import java.util.List;

import io.paperdb.Paper;

import static java.lang.Integer.parseInt;


public class AddEventFragment extends Fragment {
    private EditText nameET,titleET,descriptionET, locationCountryET,
            locationCityET,locationDistrictET,locationStreetET;
    private Button saveBtn, updateBtn;
    private Spinner categorySP;
    public Button startDatebtn, endDatebtn,startTimebtn,endTimebtn;
    private MyEventsFragment.AddNewEventListener listener;
    private int eventID = 0, eventCategoryID;
    private EventAdapter.EditEventListener editEventListener;

    public static String rslt="";
    String method;

    StartDatePickerFragment startdatePicker;
    EndDatePickerFragment enddatePicker;
    StartTimePickerFragment startTimePicker;
    EndTimePickerFragment endTimePicker;

    private RequestQueue queue;
    String PersonID;

    public AddEventFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        listener = (MyEventsFragment.AddNewEventListener) context;
        editEventListener = (EventAdapter.EditEventListener) context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_event, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        nameET = (EditText) view.findViewById(R.id.nameInput);
        titleET = (EditText)view.findViewById(R.id.titleInput);
        categorySP = (Spinner) view.findViewById(R.id.spinner);
        descriptionET = (EditText)view.findViewById(R.id.descriptionInput);
        startDatebtn = (Button) view.findViewById(R.id.startDateInput);
        endDatebtn = (Button)view.findViewById(R.id.endDateInput);
        startTimebtn = (Button)view.findViewById(R.id.startTimeInput);
        endTimebtn = (Button) view.findViewById(R.id.endTimeInput);
        locationCountryET = view.findViewById(R.id.locationCountryInput);
        locationCityET = view.findViewById(R.id.locationCityInput);
        locationDistrictET = view.findViewById(R.id.locationDistrictInput);
        locationStreetET = view.findViewById(R.id.locationStreetInput);
        saveBtn = (Button)view.findViewById(R.id.saveBtn);
        updateBtn = (Button)view.findViewById(R.id.updateBtn);

        startdatePicker = new StartDatePickerFragment();
        enddatePicker = new EndDatePickerFragment();
        startTimePicker = new StartTimePickerFragment();
        endTimePicker = new EndTimePickerFragment();
        startdatePicker.startdatebtn = startDatebtn;
        enddatePicker.enddatebtn = endDatebtn;
        startTimePicker.starttimebtn = startTimebtn;
        endTimePicker.endtimebtn = endTimebtn;
        PersonID = Paper.book().read(prevalent.UserPersonID);

        queue = Volley.newRequestQueue(getContext());

        categorySP.setSelection(0, true);
        View v = categorySP.getSelectedView();
        //((TextView)v).setTextColor(Color.WHITE);
        categorySP.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                //Change the selected item's text color
                ((TextView) view).setTextColor(Color.WHITE);
                eventCategoryID = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
            }
        });
        List<String> spinnerArray =  new ArrayList<String>();
        spinnerArray.add("--Select Your Event Category--");
        spinnerArray.add("Conference");
        spinnerArray.add("Trade Show");
        spinnerArray.add("Reunion");
        spinnerArray.add("Party");
        spinnerArray.add("Galas");
        spinnerArray.add("Expo");
        spinnerArray.add("Festival Meeting");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                getContext(), android.R.layout.simple_spinner_item, spinnerArray);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        categorySP.setAdapter(adapter);


        startDatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startdatePicker.show(AddEventFragment.this.getParentFragmentManager(),"start date picker");
            }
        });
        endDatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enddatePicker.show(AddEventFragment.this.getParentFragmentManager(),"end date picker");
            }
        });
        startTimebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTimePicker.show(AddEventFragment.this.getParentFragmentManager(),"start time picker");
            }
        });
        endTimebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                endTimePicker.show(AddEventFragment.this.getParentFragmentManager(),"end time picker");
            }
        });

        try {
            eventID = getArguments().getInt("id");
            saveBtn.setVisibility(View.GONE);
            updateBtn.setVisibility(View.VISIBLE);
            Caller c = new Caller();
            try {
                rslt = "START";
                method = "GetEventbyEventId";

                c.eventID = eventID;
                c.method = method;

                c.join();
                c.start();
                while (rslt == "START") {
                    try {
                        Thread.sleep(10);
                    } catch (Exception ex) {
                        Toast.makeText(getContext(), "Error" + ex.toString(), Toast.LENGTH_SHORT).show();
                    }
                }

            } catch (Exception ex) {
                //ad.setTitle("Error!"); ad.setMessage(ex.toString());
            }
            //ad.show();
            if (rslt.equals("Success")) {
                nameET.setText(c.name);
                titleET.setText(c.title);
                categorySP.setSelection(c.Event_Category_Id);
                descriptionET.setText(c.description);
                startDatebtn.setText(c.startDate);
                endDatebtn.setText(c.endDate);
                startTimebtn.setText(c.startTime);
                endTimebtn.setText(c.endTime);
                locationCountryET.setText(c.locationCountry);
                locationCityET.setText(c.locationCity);
                locationDistrictET.setText(c.locationDistrict);
                locationStreetET.setText(c.locationStreet);
            }

        }catch (Exception e){

        }

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = nameET.getText().toString();
                String title = titleET.getText().toString();
                String category = categorySP.getSelectedItem().toString();
                String description = descriptionET.getText().toString();
                String startDate = startDatebtn.getText().toString();
                String endDate = endDatebtn.getText().toString();
                String startTime = startTimebtn.getText().toString();
                String endTime = endTimebtn.getText().toString();
                String locationCountry = locationCountryET.getText().toString();
                String locationCity = locationCityET.getText().toString();
                String locationDistrict = locationDistrictET.getText().toString();
                String locationStreet = locationStreetET.getText().toString();

                if(TextUtils.isEmpty(name)){
                    Toast.makeText(getContext(),"Please Enter Event Name...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(title)){
                    Toast.makeText(getContext(),"Please Enter Event Title...",Toast.LENGTH_LONG).show();
                }
                if(category.equals("--Select Your Event Category--")){
                    Toast.makeText(getContext(),"Please Select Event Category...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(description)){
                    Toast.makeText(getContext(),"Please Enter Event Description...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(startDate)){
                    Toast.makeText(getContext(),"Please Enter Event Start Date...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(endDate)){
                    Toast.makeText(getContext(),"Please Enter Event End Date...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(startTime)){
                    Toast.makeText(getContext(),"Please Enter Event Start Time...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(endTime)){
                    Toast.makeText(getContext(),"Please Enter Event End Time...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(locationCountry)){
                    Toast.makeText(getContext(),"Please Enter Event's Country Location...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(locationCity)){
                    Toast.makeText(getContext(),"Please Enter Event's City Location...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(locationDistrict)){
                    Toast.makeText(getContext(),"Please Enter Event's District Location...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(locationStreet)){
                    Toast.makeText(getContext(),"Please Enter Event's Street Location...",Toast.LENGTH_LONG).show();
                }
                else {

                    try {
                        rslt = "START";
                        method = "EventInsert";
                        Caller c = new Caller();

                        c.name = name;
                        c.title = title;
                        c.eventCategoryID = eventCategoryID;
                        c.description = description;
                        c.startDate = startDate;
                        c.endDate = endDate;
                        c.startTime = startTime;
                        c.endTime = endTime;
                        c.locationCountry = locationCountry;
                        c.locationCity = locationCity;
                        c.locationDistrict = locationDistrict;
                        c.locationStreet = locationStreet;
                        c.personID = parseInt(PersonID);
                        c.method = method;

                        c.join();
                        c.start();
                        while (rslt == "START") {
                            try {
                                Thread.sleep(10);
                            } catch (Exception ex) {
                                Toast.makeText(getContext(), "Error" + ex.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }

                    } catch (Exception ex) {
                        //ad.setTitle("Error!"); ad.setMessage(ex.toString());
                    }
                    //ad.show();
                    if (parseInt(rslt)>0) {
                        Toast.makeText(getContext(), "New Event Saved Successfully...!!", Toast.LENGTH_SHORT).show();
                        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                        getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new MyEventsFragment()).commit() ;
                    } else {
                        Toast.makeText(getContext(), "OOOPSSS....!! Something Went Wrong.. ", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });

        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameET.getText().toString();
                String title = titleET.getText().toString();
                String category = categorySP.getSelectedItem().toString();
                String description = descriptionET.getText().toString();
                String startDate = startDatebtn.getText().toString();
                String endDate = endDatebtn.getText().toString();
                String startTime = startTimebtn.getText().toString();
                String endTime = endTimebtn.getText().toString();
                String locationCountry = locationCountryET.getText().toString();
                String locationCity = locationCityET.getText().toString();
                String locationDistrict = locationDistrictET.getText().toString();
                String locationStreet = locationStreetET.getText().toString();


                try {
                    rslt="START";
                    method="EventUpdate";
                    Caller c=new Caller();

                    c.eventID = eventID;
                    c.name = name;
                    c.title = title;
                    c.eventCategoryID = eventCategoryID;
                    c.description = description;
                    c.startDate = startDate;
                    c.endDate = endDate;
                    c.startTime = startTime;
                    c.endTime = endTime;
                    c.locationCountry = locationCountry;
                    c.locationCity = locationCity;
                    c.locationDistrict = locationDistrict;
                    c.locationStreet = locationStreet;
                    c.personID = parseInt(PersonID);
                    c.method = method;

                    c.join(); c.start();
                    while(rslt=="START") {
                        try {
                            Thread.sleep(10);
                        }catch(Exception ex) {
                            Toast.makeText(getContext(), "Error"+ex.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }

                }catch(Exception ex) {
                    //ad.setTitle("Error!"); ad.setMessage(ex.toString());
                }
                //ad.show();
                if(parseInt(rslt)>0) {
                    Toast.makeText(getContext(), " Event Updated Successfully...!!", Toast.LENGTH_SHORT).show();
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new MyEventsFragment()).commit() ;
                }
                else {
                    Toast.makeText(getContext(), "OOOPSSS....!! Something Went Wrong.. ", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

}

