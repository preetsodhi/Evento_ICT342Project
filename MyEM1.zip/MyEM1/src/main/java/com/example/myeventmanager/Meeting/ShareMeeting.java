package com.example.myeventmanager.Meeting;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;

import com.example.myeventmanager.R;
import com.example.myeventmanager.Service.Caller;

import java.util.ArrayList;
import java.util.List;

public class ShareMeeting extends FragmentActivity {

    EditText msg, num;
    Button btn_send;
    int meetingId;

    public static String rslt="";
    String method;
    Caller c;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.share_meeting);
        c = new Caller();
        msg = (EditText) findViewById(R.id.messageED);
        num = (EditText) findViewById(R.id.numberED);
        btn_send = (Button) findViewById(R.id.send_btn);
        Bundle extras = getIntent().getExtras();
        meetingId = extras.getInt("meetingid");

        try {
            rslt="START";
            method="GetMeetingbyMeetingId";

            c.meetingID = meetingId;
            c.method = method;

            c.join(); c.start();
            while(rslt=="START") {
                try {
                    Thread.sleep(10);
                }catch(Exception ex) {
                    Toast.makeText(getApplicationContext(), "Error"+ex.toString(), Toast.LENGTH_SHORT).show();
                }
            }

        }catch(Exception ex) {
            //ad.setTitle("Error!"); ad.setMessage(ex.toString());
        }
        //ad.show();
        if(rslt.equals("Success")) {
            int a  = 0;
            //Toast.makeText(getApplicationContext(), " Meeting Deleted Successfully...!!", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(getApplicationContext(), "OOOPSSS....!! Something Went Wrong.. ", Toast.LENGTH_SHORT).show();
        }

        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msgg = msg.getText().toString();
                String numm = num.getText().toString();
                String meetingName = c.name;
                String meetingTitle = c.title;
                String meetingType = c.type;
                String meetingDescription = c.description;
                String meetingStartDate = c.startDate;
                String meetingEndDate = c.endDate;
                String meetingStartTime = c.startTime;
                String meetingEndTime = c.endTime;
                String meetingStreet = c.locationStreet;
                String meetingCity = c.locationCity;
                String meetingDistrict = c.locationDistrict;
                String meetingCountry = c.locationCountry;

                boolean installed = appInstalledOrNot("com.whatsapp");

                if(installed){
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("http://api.whatsapp.com/send?phone="+numm+"&text="+msgg+
                            "\n\n\nMeeting Details:"+
                            "\n\nName: "+meetingName+"\nTitle: "+meetingTitle+"\nType: "+meetingType+
                            "\nDescription: "+meetingDescription+"\nStart Date: "+meetingStartDate+"\nEnd Date: "+meetingEndDate+
                            "\nStart Time: "+meetingStartTime+"\nEnd Time: "+meetingEndTime+
                            "\nAddress: "+meetingStreet+", "+meetingCity+", "+meetingDistrict+", "+meetingCountry));
                    startActivity(intent);
                }
                else {
                    Toast.makeText(ShareMeeting.this,"WhatsApp not installed on your device",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public boolean appInstalledOrNot(String url){
        PackageManager packageManager = getPackageManager();
        boolean app_installed;
        try{
            packageManager.getPackageInfo(url,PackageManager.GET_ACTIVITIES);
            app_installed = true;

        }catch (PackageManager.NameNotFoundException e){
            app_installed = false;
        }
        return  app_installed;
    }




}
