package com.example.myeventmanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;

import com.example.myeventmanager.Prevalent.prevalent;
import com.example.myeventmanager.Service.Caller;

import java.util.Calendar;
import static java.lang.Integer.parseInt;

import io.paperdb.Paper;

public class MainActivity extends AppCompatActivity {

    private Button main_join_now_btn, main_login_btn;
    private ProgressDialog loadingBar;

    String method;
    public static String rslt="";
    String UserPhoneKey, UserPasswordKey, PersonID;
    int UserPersonID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Paper.init(this);
        loadingBar = new ProgressDialog(this);


        UserPhoneKey = Paper.book().read(prevalent.UserPhoneKey);
        UserPasswordKey = Paper.book().read(prevalent.UserPasswordKey);
        PersonID = Paper.book().read(prevalent.UserPersonID);

        if (UserPhoneKey !="" && UserPasswordKey != "")
        {
            if (!TextUtils.isEmpty(UserPhoneKey)  &&  !TextUtils.isEmpty(UserPasswordKey))
            {
                AllowAccess(UserPhoneKey, UserPasswordKey);
                loadingBar.setTitle("Already Logged in");
                loadingBar.setMessage("Please wait.....");
                loadingBar.setCanceledOnTouchOutside(false);
                loadingBar.show();
            }
        }

        requestWindowFeature(Window.FEATURE_NO_TITLE);//will hide the title
        getSupportActionBar().hide(); //hide the title bar
        setContentView(R.layout.activity_main);

        main_join_now_btn = (Button) findViewById(R.id.main_join_now_btn);
        main_login_btn = (Button) findViewById(R.id.main_login_btn);
        loadingBar = new ProgressDialog(this);

        main_login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        main_join_now_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }
    private void AllowAccess(final String phoneno, final String password)
    {
        try {
            rslt = "START";
            method = "Login";
            Caller c = new Caller();

            c.phoneNo = phoneno;
            c.password = password;
            c.method = method;

            c.join(); c.start();
            while (rslt == "START") {
                try {
                    Thread.sleep(10);
                } catch (Exception ex) {
                    Toast.makeText(getApplicationContext(), "Error " + ex.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception ex) {
            //ad.setTitle("Error!"); ad.setMessage(ex.toString());
        }
        if (parseInt(rslt)>0) {
            loadingBar.dismiss();
            Paper.book().write(prevalent.UserPersonID, rslt);
            Intent intent = new Intent(MainActivity.this, HomeActivity.class);
            startActivity(intent);
        } else
            Toast.makeText(getApplicationContext(), "Sorry!! Something went wrong.. ", Toast.LENGTH_LONG).show();
    }
}
