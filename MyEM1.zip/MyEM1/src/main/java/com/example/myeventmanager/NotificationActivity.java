package com.example.myeventmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

public class NotificationActivity extends AppCompatActivity {
    TextView tv32;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        tv32 = (TextView) findViewById(R.id.tv32);
        String message = getIntent().getStringExtra("message");
        tv32.setText(message);
    }
}
