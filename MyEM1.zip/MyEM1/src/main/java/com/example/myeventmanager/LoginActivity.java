package com.example.myeventmanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myeventmanager.Prevalent.prevalent;
import com.example.myeventmanager.Service.Caller;
import com.rey.material.widget.CheckBox;

import io.paperdb.Paper;

import static java.lang.Integer.parseInt;

public class LoginActivity extends AppCompatActivity {

    private Button btn_Login;
    private EditText login_phoneno, login_password;
    private TextView forgot_password;
    private ProgressDialog loadingBar;
    public int personID;

    String phoneno,password;

    String method;
    public static String rslt="";

    private String parentDbName = "Users";
    private CheckBox chkBoxRememberMe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_login);

        btn_Login = (Button)findViewById(R.id.login_btn);
        login_phoneno = (EditText)findViewById(R.id.login_phoneno);
        login_password = (EditText)findViewById(R.id.login_password);
        forgot_password = (TextView)findViewById(R.id.forget_password_link);
        loadingBar = new ProgressDialog(this);

        chkBoxRememberMe = (CheckBox) findViewById(R.id.remember_me);
        Paper.init(this);

        btn_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginUser();
            }
        });
        forgot_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LoginActivity.this,ResetPasswordActivity.class);
                startActivity(i);
            }
        });

    }
    private void LoginUser() {
        phoneno = login_phoneno.getText().toString();
        password = login_password.getText().toString();

        if(TextUtils.isEmpty(phoneno)){
            Toast.makeText(this,"Please Enter Your Mobile Number...",Toast.LENGTH_LONG).show();
        }
        if(TextUtils.isEmpty(password)){
            Toast.makeText(this,"Please Enter Your Password...",Toast.LENGTH_LONG).show();
        }
        else
        {
            loadingBar.setTitle("Logging In");
            loadingBar.setMessage("Please wait while we are checking the credentials.");
            loadingBar.setCanceledOnTouchOutside(false);
            loadingBar.show();

            AllowAccessToAccount(phoneno,password);}
    }


    public void AllowAccessToAccount(final String phoneno, final String password) {

        if(chkBoxRememberMe.isChecked())
        {
            Paper.book().write(prevalent.UserPhoneKey, phoneno);
            Paper.book().write(prevalent.UserPasswordKey, password);
        }

        try {
            rslt = "START";
            method = "Login";
            Caller c = new Caller();

            c.phoneNo = phoneno;
            c.password = password;
            c.method = method;

            c.join(); c.start();
            while (rslt == "START") {
                try {
                    Thread.sleep(10);
                } catch (Exception ex) {
                    Toast.makeText(getApplicationContext(), "Error " + ex.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception ex) {
            //ad.setTitle("Error!"); ad.setMessage(ex.toString());
        }
        if ((parseInt(rslt)>0)) {
            personID = parseInt(rslt);
            Paper.book().write(prevalent.UserPersonID, rslt);
            loadingBar.dismiss();
            Intent i = new Intent(getApplicationContext(), HomeActivity.class);
            startActivity(i);
            finish();

        } else {
            Toast.makeText(getApplicationContext(), "MOBILE NUMBER OR PASSWORD IS INCORRECT ", Toast.LENGTH_SHORT).show();
            loadingBar.dismiss();
        }
    }


}

