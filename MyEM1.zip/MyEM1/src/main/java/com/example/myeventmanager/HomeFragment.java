package com.example.myeventmanager;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myeventmanager.Event.Event;
import com.example.myeventmanager.Service.Caller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static java.lang.Integer.parseInt;

public class HomeFragment extends Fragment {

    private static final String TAG = "HomeFragment";

    ViewFlipper v_flipper;
    RecyclerView recyclerViewEvents;
    RecyclerViewAdapter1 adapterEvents ;
    private List<Event> eventList = new ArrayList<>();

    String date = "05/06/2020";

    private ArrayList<String> mNames = new ArrayList<>();
    private ArrayList<String> mImageUrls = new ArrayList<>();


    String method;
    public static String rslt="";
    Caller c;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_home,container,false);

        v_flipper = (ViewFlipper) rootView.findViewById(R.id.v_flipper);
        recyclerViewEvents = rootView.findViewById(R.id.recyclerview1);
        c = new Caller();

        return rootView;
    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        int image[] = {R.drawable.slide1,R.drawable.slide2,R.drawable.slide3,
                R.drawable.slide4,R.drawable.slide5,R.drawable.slide6};
        callupcomingevents();
       // getImages();

        Date todaydate = new Date();
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        String dateToStr = format.format(todaydate);
        /*if(dateToStr.equals(date))
        {
            setNotif();
        }

         */
        if(eventList.size()>0)
            setNotif();

        for(int i = 0; i < image.length; i++)
        {
            flipperImages(image[i]);
        }


    }

    private void callupcomingevents() {
        try {
            rslt = "START";
            method = "GetAllUpcomingEvents";
            c = new Caller();
            c.method = method;

            c.join(); c.start();
            while (rslt == "START") {
                try {
                    Thread.sleep(10);
                } catch (Exception ex) {
                    Toast.makeText(getContext(), "Error " + ex.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception ex) {
            //ad.setTitle("Error!"); ad.setMessage(ex.toString());
        }
        if (rslt.equals("Success")){
            for(int i = 0; i<c.eDTO.length; i++)
            {
                if(i%2 == 0)
                    mImageUrls.add("https://leedsparkingservices.com/wp-content/uploads/2017/07/concerts_sports_events.jpg");
                else
                    mImageUrls.add("https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQwehVlFPeRe9hRs3CbVkvcMxcppgTE1VA3-V9yA1YjsHXwnC4m&usqp=CAU");
            }
            initRecyclerView();

        } else {
            Toast.makeText(getContext(), "OOOOPSSS Something went wrong...!!", Toast.LENGTH_LONG).show();
        }
    }


    public void flipperImages( int image){

        ImageView imageView = new ImageView(getContext());
        imageView.setBackgroundResource(image);

        v_flipper.addView(imageView);
        v_flipper.setFlipInterval(3000);

        v_flipper.setInAnimation(getContext(),android.R.anim.slide_in_left);
        v_flipper.setOutAnimation(getContext(),android.R.anim.slide_out_right);

    }
    private void getImages(){
        mImageUrls.add("https://images.unsplash.com/photo-1548704686-f0a484c1bd67?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60");
        mNames.add("Aura");
        mImageUrls.add("https://images.unsplash.com/photo-1419064642531-e575728395f2?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60");
        mNames.add("Micfest");
        /*mImageUrls.add("https://images.unsplash.com/photo-1532274402911-5a369e4c4bb5?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60");
        mNames.add("Spectrum");
        mImageUrls.add("https://images.unsplash.com/photo-1433838552652-f9a46b332c40?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60");
        mNames.add("IIFA");
        mImageUrls.add("https://images.unsplash.com/photo-1506260408121-e353d10b87c7?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60");
        mNames.add("Oasis-BITS Pilani");
        mImageUrls.add("https://images.unsplash.com/photo-1506744038136-46273834b3fb?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjI0MX0&auto=format&fit=crop&w=500&q=60");
        mNames.add("Phoenix");*/

        initRecyclerView();

    }



    private void initRecyclerView(){
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL,false);
        recyclerViewEvents.setLayoutManager(layoutManager);
        adapterEvents = new RecyclerViewAdapter1(getContext(),c.Event_Name,mImageUrls);
        recyclerViewEvents.setAdapter(adapterEvents);

    }
    private void setNotif() {

        String message = "You Have Pending Events and Meetings";
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext())
                .setSmallIcon(R.drawable.ic_person_white)
                .setContentTitle("Reminder")
                .setContentText(message)
                .setAutoCancel(true);

        Intent intent = new Intent(getContext(), NotificationActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("message",message);

        PendingIntent pendingIntent = PendingIntent.getActivity(getContext(),0,intent,PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(pendingIntent);

        NotificationManager notificationManager = (NotificationManager)getActivity().getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            String channelId = "Your_channel_id";
            NotificationChannel channel = new NotificationChannel(
                    channelId,
                    "Channel human readable title",
                    NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(channel);
            builder.setChannelId(channelId);
        }
        notificationManager.notify(0,builder.build());
    }
}
