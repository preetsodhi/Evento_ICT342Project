package com.example.myeventmanager.Event;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;

import com.example.myeventmanager.R;
import com.example.myeventmanager.Service.Caller;

public class EventDetailActivity extends AppCompatActivity {

    ListView listView1;
    Caller c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.event_detail);

        Intent intent = getIntent();

        listView1 = (ListView) findViewById(R.id.listView1);
        c = new Caller();
        String address = "";
        Bundle b = intent.getExtras();
        String name = b.getString("name");
        String title = b.getString("title");
        String category = b.getString("category");
        String description = b.getString("desc");
        String startDate = b.getString("startDate");
        String endDate = b.getString("endDate");
        String startTime = b.getString("startTime");
        String endTime = b.getString("endTime");
        String country = b.getString("country");
        String city = b.getString("city");
        String district = b.getString("district");
        String street = b.getString("street");

        address = street +", "+city+", "+district+", "+country;
        listView1.setAdapter(new MyAdapter4(EventDetailActivity.this,name,title,
                category,description,startDate,endDate,startTime,endTime,address));
    }
}
