package com.example.myeventmanager.Prevalent;

public class prevalent {

    public static final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";
    public static final String UserPersonID = "0" ;

}
