package com.example.myeventmanager.Meeting;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myeventmanager.R;

import java.util.List;

public class MeetingAdapter extends RecyclerView.Adapter<MeetingAdapter.MeetingViewHolder> {
    private List<MeetingDTO> meetingList;
    private Context context;
    private MeetingAdapter.EditMeetingListener editMeetingListener;
    private MeetingAdapter.DeleteMeetingListener deleteMeetingListener;
    private MeetingAdapter.OpenMapListener openMapListener;
    private OpenWhatsAppListener openWhatsAppListener;
    private OpenMeetingDetailListener openMeetingDetailListener;

    public static String rslt="";
    String method;

    public MeetingAdapter(Context context, List<MeetingDTO> meetingList) {
        this.meetingList = meetingList;
        this.context = context;
        editMeetingListener = (MeetingAdapter.EditMeetingListener) context;
        deleteMeetingListener = (MeetingAdapter.DeleteMeetingListener) context;
        openMapListener = (MeetingAdapter.OpenMapListener) context;
        openWhatsAppListener = (OpenWhatsAppListener) context;
        openMeetingDetailListener = (OpenMeetingDetailListener) context;
    }

    @NonNull
    @Override
    public MeetingAdapter.MeetingViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.meeting_row, viewGroup, false);
        return new MeetingAdapter.MeetingViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MeetingAdapter.MeetingViewHolder holder, final int i) {
        final MeetingDTO meeting = meetingList.get(i);
        //holder.imageView.setImageResource(event.getImage());
        holder.nameTV.setText(meeting.getMeeting_Name());
        holder.categoryTV.setText(meeting.getMeeting_Category());
        holder.locationTV.setText(meeting.getCity());
        holder.startdateTV.setText(meeting.getStart_Date());
        holder.menuTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(view.getContext(), view);
                MenuInflater inflater = popupMenu.getMenuInflater();
                inflater.inflate(R.menu.meeting_menu, popupMenu.getMenu());
                popupMenu.show();
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()){
                            case R.id.item_details:
                                openMeetingDetailListener.onOpenDetailMeetingClicked(meeting.getMeetingID());
                                break;
                            case R.id.item_delete:
                                deleteMeetingListener.onDeleteBtnClickedMeeting(meeting.getMeetingID());
                                break;
                            case R.id.item_edit:
                                editMeetingListener.onEditBtnClickedMeeting(meeting.getMeetingID());
                                break;
                            case R.id.item_openMap:
                                openMapListener.onOpenMapBtnClickedMeeting(meeting.getMeetingID());
                                break;
                            case R.id.item_share:
                                openWhatsAppListener.onOpenWBtnClickedMeeting(meeting.getMeetingID());
                                break;
                        }
                        return false;
                    }
                });
            }
        });

    }

    @Override
    public int getItemCount() {
        return meetingList.size();
    }

    class MeetingViewHolder extends RecyclerView.ViewHolder{
        ImageView imageView;
        TextView nameTV, locationTV, startdateTV,categoryTV, menuTV;

        public MeetingViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.row_imageview);
            nameTV = itemView.findViewById(R.id.row_name);
            locationTV = itemView.findViewById(R.id.row_location);
            startdateTV = itemView.findViewById(R.id.row_startdate);
            categoryTV = itemView.findViewById(R.id.row_category);
            menuTV = itemView.findViewById(R.id.row_menu);
        }
    }

    public interface EditMeetingListener{
        void onEditBtnClickedMeeting(int meetingID);
        void onEditCompleteMeeting();
    }
    public interface DeleteMeetingListener{
        void onDeleteBtnClickedMeeting(int meetingID);
        void onDeleteCompleteMeeting();
    }
    public interface OpenMapListener{
        void onOpenMapBtnClickedMeeting(int meetingID);
        void onOpenMapCompleteMeeting();
    }
    public interface OpenWhatsAppListener{
        void onOpenWBtnClickedMeeting(int meetingID);
        void onOpenWCompleteMeeting();
    }
    public interface OpenMeetingDetailListener{
        void onOpenDetailMeetingClicked(int meetingID);
        void onOpenDetailMeetingComplete();
    }
}


