package com.example.myeventmanager.Meeting;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.example.myeventmanager.DateAndTimePicker.EndDatePickerFragment;
import com.example.myeventmanager.DateAndTimePicker.EndTimePickerFragment;
import com.example.myeventmanager.DateAndTimePicker.StartDatePickerFragment;
import com.example.myeventmanager.DateAndTimePicker.StartTimePickerFragment;
import com.example.myeventmanager.HomeActivity;
import com.example.myeventmanager.HomeFragment;
import com.example.myeventmanager.MeetingsFragment;
import com.example.myeventmanager.NotificationActivity;
import com.example.myeventmanager.Prevalent.prevalent;
import com.example.myeventmanager.R;
import com.example.myeventmanager.Service.Caller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import io.paperdb.Paper;

import static android.content.Context.ALARM_SERVICE;
import static java.lang.Integer.parseInt;

public class AddMeetingFragment extends Fragment {
    private EditText nameET,titleET,descriptionET,locationCountryET,
            locationCityET,locationDistrictET,locationStreetET;
    private Button saveBtn, updateBtn;
    public Spinner categorySP;
    public Button startDatebtn, endDatebtn,startTimebtn,endTimebtn;
    private MeetingsFragment.AddNewMeetingListener listener;
    private int meetingID = 0, meetingTypeID;
    private MeetingAdapter.EditMeetingListener editMeetingListener;

    StartDatePickerFragment startdatePicker;
    EndDatePickerFragment enddatePicker;
    StartTimePickerFragment starttimePicker;
    EndTimePickerFragment endTimePicker;

    public static String rslt="";
    String method;
    String PersonID;

    public AddMeetingFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        listener = (MeetingsFragment.AddNewMeetingListener) context;
        editMeetingListener = (MeetingAdapter.EditMeetingListener) context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_meeting, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        nameET = view.findViewById(R.id.nameInput);
        titleET = view.findViewById(R.id.titleInput);
        categorySP = view.findViewById(R.id.spinner);
        descriptionET = view.findViewById(R.id.descriptionInput);
        startDatebtn = view.findViewById(R.id.startDateInput);
        endDatebtn = view.findViewById(R.id.endDateInput);
        startTimebtn = view.findViewById(R.id.startTimeInput);
        endTimebtn = view.findViewById(R.id.endTimeInput);
        locationCountryET = view.findViewById(R.id.locationCountryInput);
        locationCityET = view.findViewById(R.id.locationCityInput);
        locationDistrictET = view.findViewById(R.id.locationDistrictInput);
        locationStreetET = view.findViewById(R.id.locationStreetInput);
        saveBtn = view.findViewById(R.id.saveBtn);
        updateBtn = view.findViewById(R.id.updateBtn);

        startdatePicker = new StartDatePickerFragment();
        enddatePicker = new EndDatePickerFragment();
        starttimePicker = new StartTimePickerFragment();
        endTimePicker = new EndTimePickerFragment();
        startdatePicker.startdatebtn = startDatebtn;
        enddatePicker.enddatebtn = endDatebtn;
        starttimePicker.starttimebtn = startTimebtn;
        endTimePicker.endtimebtn = endTimebtn;

        //getMeetingCategory();
        PersonID = Paper.book().read(prevalent.UserPersonID);

        categorySP.setSelection(0, true);
        View v = categorySP.getSelectedView();
        //((TextView)v).setTextColor(Color.WHITE);
        categorySP.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                //Change the selected item's text color
                ((TextView) view).setTextColor(Color.WHITE);
                meetingTypeID = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
            }
        });
        List<String> spinnerArray =  new ArrayList<String>();
        spinnerArray.add("--Select Your Meeting Type--");
        spinnerArray.add("Seminar");
        spinnerArray.add("Conference");
        spinnerArray.add("Job Interview");
        spinnerArray.add("Workshop");
        spinnerArray.add("Business Meeting");
        spinnerArray.add("Board Meeting");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                getContext(), android.R.layout.simple_spinner_item, spinnerArray);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        categorySP.setAdapter(adapter);

        startDatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startdatePicker.show(AddMeetingFragment.this.getParentFragmentManager(),"start date picker");
            }
        });
        endDatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enddatePicker.show(AddMeetingFragment.this.getParentFragmentManager(),"end date picker");
            }
        });
        startTimebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                starttimePicker.show(AddMeetingFragment.this.getParentFragmentManager(),"start time picker");
            }
        });
        endTimebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                endTimePicker.show(AddMeetingFragment.this.getParentFragmentManager(),"end time picker");
            }
        });

        try {
            meetingID = getArguments().getInt("id");
            saveBtn.setVisibility(View.GONE);
            updateBtn.setVisibility(View.VISIBLE);
            Caller c = new Caller();
            try {
                rslt = "START";
                method = "GetMeetingbyMeetingId";

                c.meetingID = meetingID;
                c.method = method;

                c.join();
                c.start();
                while (rslt == "START") {
                    try {
                        Thread.sleep(10);
                    } catch (Exception ex) {
                        Toast.makeText(getContext(), "Error" + ex.toString(), Toast.LENGTH_SHORT).show();
                    }
                }

            } catch (Exception ex) {
                //ad.setTitle("Error!"); ad.setMessage(ex.toString());
            }
            //ad.show();
            if (rslt.equals("Success")) {
                nameET.setText(c.name);
                titleET.setText(c.title);
                categorySP.setSelection(c.MeetingTypeId);
                descriptionET.setText(c.description);
                startDatebtn.setText(c.startDate);
                endDatebtn.setText(c.endDate);
                startTimebtn.setText(c.startTime);
                endTimebtn.setText(c.endTime);
                locationCountryET.setText(c.locationCountry);
                locationCityET.setText(c.locationCity);
                locationDistrictET.setText(c.locationDistrict);
                locationStreetET.setText(c.locationStreet);
            }

        }catch (Exception e){

        }


        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = nameET.getText().toString();
                String title = titleET.getText().toString();
                String category = categorySP.getSelectedItem().toString();
                String description = descriptionET.getText().toString();
                String startDate = startDatebtn.getText().toString();
                String endDate = endDatebtn.getText().toString();
                String startTime = startTimebtn.getText().toString();
                String endTime = endTimebtn.getText().toString();
                String locationCountry = locationCountryET.getText().toString();
                String locationCity = locationCityET.getText().toString();
                String locationDistrict = locationDistrictET.getText().toString();
                String locationStreet = locationStreetET.getText().toString();

                if(TextUtils.isEmpty(name)){
                    Toast.makeText(getContext(),"Please Enter Meeting's Name...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(title)){
                    Toast.makeText(getContext(),"Please Enter Meeting's Title...",Toast.LENGTH_LONG).show();
                }
                if(category.equals("--Select Your Meeting Type--")){
                    Toast.makeText(getContext(),"Please Select Meeting's Category...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(description)){
                    Toast.makeText(getContext(),"Please Enter Meeting's Description...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(startDate)){
                    Toast.makeText(getContext(),"Please Enter Meeting's Start Date...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(endDate)){
                    Toast.makeText(getContext(),"Please Enter Meeting's End Date...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(startTime)){
                    Toast.makeText(getContext(),"Please Enter Meeting's Start Time...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(endTime)){
                    Toast.makeText(getContext(),"Please Enter Meeting's End Time...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(locationCountry)){
                    Toast.makeText(getContext(),"Please Enter Meeting's Country Location...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(locationCity)){
                    Toast.makeText(getContext(),"Please Enter Meeting's City Location...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(locationDistrict)){
                    Toast.makeText(getContext(),"Please Enter Meeting's District Location...",Toast.LENGTH_LONG).show();
                }
                if(TextUtils.isEmpty(locationStreet)){
                    Toast.makeText(getContext(),"Please Enter Meeting's Street Location...",Toast.LENGTH_LONG).show();
                }
                else {
                    try {
                        rslt = "START";
                        method = "AddMeeting";
                        Caller c = new Caller();

                        c.name = name;
                        c.title = title;
                        c.meetingTypeID = meetingTypeID;
                        c.description = description;
                        c.startDate = startDate;
                        c.endDate = endDate;
                        c.startTime = startTime;
                        c.endTime = endTime;
                        c.locationCountry = locationCountry;
                        c.locationCity = locationCity;
                        c.locationDistrict = locationDistrict;
                        c.locationStreet = locationStreet;
                        c.personID = parseInt(PersonID);
                        c.method = method;

                        c.join();
                        c.start();
                        while (rslt == "START") {
                            try {
                                Thread.sleep(10);
                            } catch (Exception ex) {
                                Toast.makeText(getContext(), "Error" + ex.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }

                    } catch (Exception ex) {
                        //ad.setTitle("Error!"); ad.setMessage(ex.toString());
                    }
                    //ad.show();
                    if (parseInt(rslt)>0) {
                        Toast.makeText(getContext(), " New Meeting Saved Successfully...!!", Toast.LENGTH_SHORT).show();
                        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                        getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new MeetingsFragment()).commit() ;
                        //setNotif();
                    } else {
                        Toast.makeText(getContext(), "OOOPSSS....!! Something Went Wrong.. ", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });

        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameET.getText().toString();
                String title = titleET.getText().toString();
                String category = categorySP.getSelectedItem().toString();
                String description = descriptionET.getText().toString();
                String startDate = startDatebtn.getText().toString();
                String endDate = endDatebtn.getText().toString();
                String startTime = startTimebtn.getText().toString();
                String endTime = endTimebtn.getText().toString();
                String locationCountry = locationCountryET.getText().toString();
                String locationCity = locationCityET.getText().toString();
                String locationDistrict = locationCountryET.getText().toString();
                String locationStreet = locationStreetET.getText().toString();

                try {
                    rslt="START";
                    method="UpdateMeeting";
                    Caller c=new Caller();

                    c.meetingID = meetingID;
                    c.name = name;
                    c.title = title;
                    c.meetingTypeID = meetingTypeID;
                    c.description = description;
                    c.startDate = startDate;
                    c.endDate = endDate;
                    c.startTime = startTime;
                    c.endTime = endTime;
                    c.locationCountry = locationCountry;
                    c.locationCity = locationCity;
                    c.locationDistrict = locationDistrict;
                    c.locationStreet = locationStreet;
                    c.personID = parseInt(PersonID);
                    c.method = method;

                    c.join(); c.start();
                    while(rslt=="START") {
                        try {
                            Thread.sleep(10);
                        }catch(Exception ex) {
                            Toast.makeText(getContext(), "Error"+ex.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }

                }catch(Exception ex) {
                    //ad.setTitle("Error!"); ad.setMessage(ex.toString());
                }
                //ad.show();
                if(parseInt(rslt)>0) {
                    Toast.makeText(getContext(), " Meeting Updated Successfully...!!", Toast.LENGTH_SHORT).show();
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new MeetingsFragment()).commit() ;
                }
                else
                    Toast.makeText(getContext(), "OOOPSSS....!! Something Went Wrong.. ", Toast.LENGTH_SHORT).show();


                /*final int updatedRow = dataSource.updateMeetingById(meeting);
                if(updatedRow > 0){
                    Toast.makeText(getActivity(),"updated", Toast.LENGTH_SHORT).show();
                    editMeetingListener.onEditCompleteMeeting();
                }*/
            }
        });
    }

    private void getMeetingCategory() {
        Caller c = new Caller();
        try {
            rslt = "START";
            method = "GetAllMeeting";

            //c.personID = login.personID;
            c.method = method;
            c.join(); c.start();
            while (rslt == "START") {
                try {
                    Thread.sleep(10);
                } catch (Exception ex) {
                    Toast.makeText(getContext(), "Error " + ex.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception ex) {
            //ad.setTitle("Error!"); ad.setMessage(ex.toString());
        }
        if (!(rslt.equals(""))) {

        } else
            Toast.makeText(getContext(), "OOOOPSSS Something went wrong...!!", Toast.LENGTH_LONG).show();
    }

    private void setNotif() {

        String message = "Notif example";
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext())
                .setSmallIcon(R.drawable.ic_person_white)
                .setContentTitle("New Notification")
                .setContentText(message)
                .setAutoCancel(true);

        Intent intent = new Intent(getContext(), NotificationActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("message",message);

        PendingIntent pendingIntent = PendingIntent.getActivity(getContext(),0,intent,PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(pendingIntent);

        NotificationManager notificationManager = (NotificationManager)getActivity().getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            String channelId = "Your_channel_id";
            NotificationChannel channel = new NotificationChannel(
                    channelId,
                    "Channel human readable title",
                    NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(channel);
            builder.setChannelId(channelId);
        }
        notificationManager.notify(0,builder.build());
    }
}


