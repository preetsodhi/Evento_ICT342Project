package com.example.myeventmanager.Event;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.myeventmanager.R;

public class MyAdapter4 extends BaseAdapter {
    private String Event_Name;
    private String Event_Title;
    private String Event_Category;
    private String Event_Description;
    private String Event_StartDate;
    private String Event_EndDate;
    private String Event_StartTime;
    private String Event_EndTime;
    private String Event_Address;

    public Activity context;

    public LayoutInflater inflater;

    public MyAdapter4(Activity context, String Event_Name, String Event_Title, String Event_Category,
                      String Event_Description, String Event_StartDate, String Event_EndDate, String Event_StartTime,
                      String Event_EndTime, String Event_Address) {

        super();
        this.Event_Name = Event_Name;
        this.Event_Title = Event_Title;
        this.Event_Category = Event_Category;
        this.Event_Description = Event_Description;
        this.Event_StartDate = Event_StartDate;
        this.Event_EndDate = Event_EndDate;
        this.Event_StartTime = Event_StartTime;
        this.Event_EndTime = Event_EndTime;
        this.Event_Address = Event_Address;
        this.context = context;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return null;
    }

    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return 0;
    }
    public int getCount() {
        // TODO Auto-generated method stub
        return 1;
    }

    public class ViewHolder {

        TextView Event_Name;
        TextView Event_Title;
        TextView Event_Category;
        TextView Event_Description;
        TextView Event_StartDate;
        TextView Event_EndDate;
        TextView Event_StartTime;
        TextView Event_EndTime;
        TextView Event_Address;
    }

    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;

        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.indi_view4, null);

            holder.Event_Name = (TextView) convertView.findViewById(R.id.name);
            holder.Event_Title = (TextView) convertView.findViewById(R.id.title);
            holder.Event_Description = (TextView) convertView.findViewById(R.id.desc);
            holder.Event_Category = (TextView) convertView.findViewById(R.id.category);
            holder.Event_StartDate = (TextView) convertView.findViewById(R.id.startDate);
            holder.Event_EndDate = (TextView) convertView.findViewById(R.id.endDate);
            holder.Event_StartTime = (TextView) convertView.findViewById(R.id.startTime);
            holder.Event_EndTime = (TextView) convertView.findViewById(R.id.endTime);
            holder.Event_Address = (TextView) convertView.findViewById(R.id.address);

            convertView.setTag(holder);
        } else
            holder = (ViewHolder) convertView.getTag();
        holder.Event_Name.setText("Name: "+Event_Name);
        holder.Event_Title.setText("Title: "+Event_Title);
        holder.Event_Category.setText("Type: "+Event_Category);
        holder.Event_Description.setText("Description: "+Event_Description);
        holder.Event_StartDate.setText("Start Date: "+Event_StartDate);
        holder.Event_EndDate.setText("End Date: "+Event_EndDate);
        holder.Event_StartTime.setText("Start Time: "+Event_StartTime);
        holder.Event_EndTime.setText("End Time: "+Event_EndTime);
        holder.Event_Address.setText("Address: "+Event_Address);
        return convertView;
    }
}


