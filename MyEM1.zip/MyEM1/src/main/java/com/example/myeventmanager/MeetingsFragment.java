package com.example.myeventmanager;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myeventmanager.Meeting.Meeting;
import com.example.myeventmanager.Meeting.MeetingAdapter;
import com.example.myeventmanager.Prevalent.prevalent;
import com.example.myeventmanager.Service.Caller;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import io.paperdb.Paper;

import static java.lang.Integer.parseInt;

public class MeetingsFragment extends Fragment {

    private RecyclerView recyclerView;
    private MeetingAdapter adapter;
    private List<Meeting> meetingList = new ArrayList<>();
    private FloatingActionButton fab;
    private AddNewMeetingListener listener;

    ListView listView1;
    String PersonID;
    Caller c;

    String method;
    public static String rslt="";

    LoginActivity login;

    public MeetingsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        listener = (MeetingsFragment.AddNewMeetingListener) context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_meetings, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.recyclerview);
        c = new Caller();
        fab = view.findViewById(R.id.fab);
        login = new LoginActivity();
        PersonID = Paper.book().read(prevalent.UserPersonID);

        int r = getAllMeetings();


        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onAddNewMeeting();
            }
        });
    }

    public interface AddNewMeetingListener{
        void onAddNewMeeting();
        void onCompleteMeeting();
    }
    private int getAllMeetings() {
        try {
            rslt = "START";
            method = "GetAllMeeting";

            c.personID = parseInt(PersonID);
            c.method = method;
            c.join(); c.start();
            while (rslt == "START") {
                try {
                    Thread.sleep(10);
                } catch (Exception ex) {
                    Toast.makeText(getContext(), "Error " + ex.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception ex) {
            //ad.setTitle("Error!"); ad.setMessage(ex.toString());
        }
        if (rslt.equals("Success")){
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
            linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
            GridLayoutManager glm = new GridLayoutManager(getActivity(), 2);
            recyclerView.setLayoutManager(glm);
            adapter = new MeetingAdapter(getActivity(), Arrays.asList(c.mDTO));
            recyclerView.setAdapter(adapter);
            return 1;

        }
        else if(rslt.equals("NoMeetings")){
            return  0;
        }
        return 0;
    }
}

