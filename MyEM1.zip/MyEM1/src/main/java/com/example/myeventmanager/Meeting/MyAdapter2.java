package com.example.myeventmanager.Meeting;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.myeventmanager.R;

public class MyAdapter2 extends BaseAdapter {
    private String Meeting_Name;
    private String Meeting_Title;
    private String Meeting_Category;
    private String Meeting_Description;
    private String Meeting_StartDate;
    private String Meeting_EndDate;
    private String Meeting_StartTime;
    private String Meeting_EndTime;
    private String Meeting_Address;

    public Activity context;

    public LayoutInflater inflater;

    public MyAdapter2(Activity context, String Meeting_Name, String Meeting_Title, String Meeting_Category,
                     String Meeting_Description, String Meeting_StartDate,String Meeting_EndDate, String Meeting_StartTime,
                      String Meeting_EndTime, String Meeting_Address) {

        super();
        this.Meeting_Name = Meeting_Name;
        this.Meeting_Title = Meeting_Title;
        this.Meeting_Category = Meeting_Category;
        this.Meeting_Description = Meeting_Description;
        this.Meeting_StartDate = Meeting_StartDate;
        this.Meeting_EndDate = Meeting_EndDate;
        this.Meeting_StartTime = Meeting_StartTime;
        this.Meeting_EndTime = Meeting_EndTime;
        this.Meeting_Address = Meeting_Address;
        this.context = context;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return null;
    }

    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return 0;
    }

    public int getCount() {
        // TODO Auto-generated method stub
        return 1;
    }

    public class ViewHolder {

        TextView Meeting_Name;
        TextView Meeting_Title;
        TextView Meeting_Type;
        TextView Meeting_Description;
        TextView Meeting_StartDate;
        TextView Meeting_EndDate;
        TextView Meeting_StartTime;
        TextView Meeting_EndTime;
        TextView Meeting_Address;
    }

    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;

        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.indi_view2, null);

            holder.Meeting_Name = (TextView) convertView.findViewById(R.id.name);
            holder.Meeting_Title = (TextView) convertView.findViewById(R.id.title);
            holder.Meeting_Description = (TextView) convertView.findViewById(R.id.desc);
            holder.Meeting_Type = (TextView) convertView.findViewById(R.id.type);
            holder.Meeting_StartDate = (TextView) convertView.findViewById(R.id.startDate);
            holder.Meeting_EndDate = (TextView) convertView.findViewById(R.id.endDate);
            holder.Meeting_StartTime = (TextView) convertView.findViewById(R.id.startTime);
            holder.Meeting_EndTime = (TextView) convertView.findViewById(R.id.endTime);
            holder.Meeting_Address = (TextView) convertView.findViewById(R.id.address);

            convertView.setTag(holder);
        } else
            holder = (ViewHolder) convertView.getTag();
        holder.Meeting_Name.setText("Name: "+Meeting_Name);
        holder.Meeting_Title.setText("Title: "+Meeting_Title);
        holder.Meeting_Type.setText("Type: "+Meeting_Category);
        holder.Meeting_Description.setText("Description: "+Meeting_Description);
        holder.Meeting_StartDate.setText("Start Date: "+Meeting_StartDate);
        holder.Meeting_EndDate.setText("End Date: "+Meeting_EndDate);
        holder.Meeting_StartTime.setText("Start Time: "+Meeting_StartTime);
        holder.Meeting_EndTime.setText("End Time: "+Meeting_EndTime);
        holder.Meeting_Address.setText("Address: "+Meeting_Address);
        return convertView;
    }
}
