package com.example.myeventmanager.Event;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myeventmanager.R;

import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {
    private List<EventDTO> eventList;
    private Context context;
    private EditEventListener editEventListener;
    private DetailEventListener detailEventListener;
    private EventAdapter.OpenMapListener openMapListener;
    private OpenWhatsAppListener openWhatsAppListener;
    private EventAdapter.DeleteEventListener deleteEventListener;

    public static String rslt="";
    String method;

    public EventAdapter(Context context, List<EventDTO> eventList) {
        this.eventList = eventList;
        this.context = context;
        editEventListener = (EditEventListener) context;
        openMapListener = (EventAdapter.OpenMapListener) context;
        openWhatsAppListener = (OpenWhatsAppListener) context;
        detailEventListener = (DetailEventListener) context;
        deleteEventListener = (EventAdapter.DeleteEventListener) context;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.event_row, viewGroup, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, final int i) {
        final EventDTO event = eventList.get(i);
        //holder.imageView.setImageResource(event.getImage());
        holder.nameTV.setText(event.getEvent_Name());
        holder.categoryTV.setText(event.getEvent_Category());
        holder.locationTV.setText(event.getCity());
        holder.startdateTV.setText(event.getStart_Date());
        holder.menuTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(view.getContext(), view);
                MenuInflater inflater = popupMenu.getMenuInflater();
                inflater.inflate(R.menu.event_menu, popupMenu.getMenu());
                popupMenu.show();
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()){
                            case R.id.item_details:
                                detailEventListener.onDetailBtnClicked(event.getEventID());
                                break;
                            case R.id.item_delete:
                                deleteEventListener.onDeleteBtnClickedEvent(event.getEventID());
                                break;
                            case R.id.item_edit:
                                editEventListener.onEditBtnClicked(event.getEventID());
                                break;
                            case R.id.item_openMap:
                                openMapListener.onOpenMapBtnClickedEvent(event.getEventID());
                                break;
                            case R.id.item_share:
                                openWhatsAppListener.onOpenWBtnClickedEvent(event.getEventID());
                                break;
                        }
                        return false;
                    }
                });
            }
        });

    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    class EventViewHolder extends RecyclerView.ViewHolder{
        ImageView imageView;
        TextView nameTV, locationTV, startdateTV,categoryTV, menuTV;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.row_imageview);
            nameTV = itemView.findViewById(R.id.row_name);
            locationTV = itemView.findViewById(R.id.row_location);
            startdateTV = itemView.findViewById(R.id.row_startdate);
            categoryTV = itemView.findViewById(R.id.row_category);
            menuTV = itemView.findViewById(R.id.row_menu);
        }
    }

    public interface EditEventListener{
        void onEditBtnClicked(int eventID);
        void onEditComplete();
    }
    public interface DetailEventListener{
        void onDetailBtnClicked(int eventID);

    }
    public interface OpenMapListener{
        void onOpenMapBtnClickedEvent(int eventID);
        void onOpenMapCompleteEvent();
    }
    public interface OpenWhatsAppListener{
        void onOpenWBtnClickedEvent(int eventID);
        void onOpenWCompleteEvent();
    }
    public interface DeleteEventListener{
        void onDeleteBtnClickedEvent(int eventID);
        void onDeleteCompleteEvent();
    }

}

