package com.example.myeventmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myeventmanager.Meeting.MeetingDetailActivity;
import com.example.myeventmanager.Meeting.MyAdapter2;
import com.example.myeventmanager.Service.Caller;

public class UpcomingEventsActivity extends AppCompatActivity {

    String method;
    public static String rslt="";
    Caller c;

    ListView listView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upcoming_events);

        listView2 = (ListView) findViewById(R.id.listView2);
        callUpcomingEvents();
    }

    private void callUpcomingEvents() {
        try {
            rslt = "START";
            method = "GetAllUpcomingEvents";
            c = new Caller();
            c.method = method;

            c.join(); c.start();
            while (rslt == "START") {
                try {
                    Thread.sleep(10);
                } catch (Exception ex) {
                    Toast.makeText(getApplicationContext(), "Error " + ex.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception ex) {
            //ad.setTitle("Error!"); ad.setMessage(ex.toString());
        }
        if (rslt.equals("Success")){
            listView2.setAdapter(new MyAdapter3(UpcomingEventsActivity.this,c.Event_Name,c.Event_Title,
                    c.Event_Type,c.Event_Description,c.Event_StartDate,c.Event_EndDate,
                    c.Event_StartTime,c.Event_EndTime,c.Event_Country,c.Event_Suburb,c.Event_City,c.Event_Street));

        } else {
            Toast.makeText(getApplicationContext(), "OOOOPSSS Something went wrong...!!", Toast.LENGTH_LONG).show();
        }
    }
}
