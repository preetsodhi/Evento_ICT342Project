package com.example.myeventmanager.Meeting;

import com.google.gson.annotations.SerializedName;

public class MeetingDTO {

    @SerializedName("Meeting_Name")
    private String Meeting_Name;
    @SerializedName("Meeting_Title")
    private String Meeting_Title;
    @SerializedName("Meeting_Type")
    private String Meeting_Category;
    @SerializedName("Meeting_Description")
    private String Meeting_Description;
    @SerializedName("Start_Date")
    private String Start_Date;
    @SerializedName("End_Date")
    private String End_Date;
    @SerializedName("Start_Time")
    private String Start_Time;
    @SerializedName("End_Time")
    private String End_Time;
    @SerializedName("Country")
    private String Country;
    @SerializedName("City")
    private String City;
    @SerializedName("District")
    private String District;
    @SerializedName("Street_Address")
    private String Street_Address;
    @SerializedName("T_Meeting_Id")
    private int meetingID;
    @SerializedName("T_Person_Detail_Id")
    private int T_Person_Detail_Id;
    @SerializedName("M_Meeting_Type_Id")
    private int M_Meeting_Type_Id;

    public int getM_Meeting_Type_Id() {
        return M_Meeting_Type_Id;
    }

    public void setM_Meeting_Type_Id(int m_Meeting_Type_Id) {
        M_Meeting_Type_Id = m_Meeting_Type_Id;
    }

    public String getMeeting_Name() {
        return Meeting_Name;
    }

    public void setMeeting_Name(String meeting_Name) {
        Meeting_Name = meeting_Name;
    }

    public String getMeeting_Title() {
        return Meeting_Title;
    }

    public void setMeeting_Title(String meeting_Title) {
        Meeting_Title = meeting_Title;
    }

    public String getMeeting_Category() {
        return Meeting_Category;
    }

    public void setMeeting_Category(String meeting_Category) {
        Meeting_Category = meeting_Category;
    }

    public String getMeeting_Description() {
        return Meeting_Description;
    }

    public void setMeeting_Description(String meeting_Description) {
        Meeting_Description = meeting_Description;
    }

    public String getStart_Date() {
        return Start_Date;
    }

    public void setStart_Date(String start_Date) {
        Start_Date = start_Date;
    }

    public String getEnd_Date() {
        return End_Date;
    }

    public void setEnd_Date(String end_Date) {
        End_Date = end_Date;
    }

    public String getStart_Time() {
        return Start_Time;
    }

    public void setStart_Time(String start_Time) {
        Start_Time = start_Time;
    }

    public String getEnd_Time() {
        return End_Time;
    }

    public void setEnd_Time(String end_Time) {
        End_Time = end_Time;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String country) {
        Country = country;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getDistrict() {
        return District;
    }

    public void setDistrict(String district) {
        District = district;
    }

    public String getStreet_Address() {
        return Street_Address;
    }

    public void setStreet_Address(String street_Address) {
        Street_Address = street_Address;
    }

    public int getMeetingID() {
        return meetingID;
    }

    public void setMeetingID(int meetingID) {
        this.meetingID = meetingID;
    }

    public int getT_Person_Detail_Id() {
        return T_Person_Detail_Id;
    }

    public void setT_Person_Detail_Id(int t_Person_Detail_Id) {
        T_Person_Detail_Id = t_Person_Detail_Id;
    }
}
