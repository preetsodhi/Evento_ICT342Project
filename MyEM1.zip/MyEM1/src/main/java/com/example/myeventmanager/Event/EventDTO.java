package com.example.myeventmanager.Event;

import com.google.gson.annotations.SerializedName;

public class EventDTO {

    @SerializedName("Event_Name")
    private String Event_Name;
    @SerializedName("Event_Title")
    private String Event_Title;
    @SerializedName("Event_Category_Name")
    private String Event_Category;
    @SerializedName("Event_Description")
    private String Event_Description;
    @SerializedName("Event_Start_Date")
    private String Start_Date;
    @SerializedName("Event_End_Date")
    private String End_Date;
    @SerializedName("Event_Start_Time")
    private String Start_Time;
    @SerializedName("Event_End_Time")
    private String End_Time;
    @SerializedName("Country")
    private String Country;
    @SerializedName("City")
    private String City;
    @SerializedName("District")
    private String District;
    @SerializedName("Street_Address")
    private String Street_Address;
    @SerializedName("T_Event_Id")
    private int eventID;
    @SerializedName("T_Person_Detail_Id")
    private int T_Person_Detail_Id;
    @SerializedName("M_Event_Category_Id")
    private int M_Event_Category_Id;

    public int getM_Event_Category_Id() {
        return M_Event_Category_Id;
    }

    public void setM_Event_Category_Id(int m_Event_Category_Id) {
        M_Event_Category_Id = m_Event_Category_Id;
    }

    public String getEvent_Name() {
        return Event_Name;
    }

    public void setEvent_Name(String event_Name) {
        Event_Name = event_Name;
    }

    public String getEvent_Title() {
        return Event_Title;
    }

    public void setEvent_Title(String event_Title) {
        Event_Title = event_Title;
    }

    public String getEvent_Category() {
        return Event_Category;
    }

    public void setEvent_Category(String event_Category) {
        Event_Category = event_Category;
    }

    public String getEvent_Description() {
        return Event_Description;
    }

    public void setEvent_Description(String event_Description) {
        Event_Description = event_Description;
    }

    public String getStart_Date() {
        return Start_Date;
    }

    public void setStart_Date(String start_Date) {
        Start_Date = start_Date;
    }

    public String getEnd_Date() {
        return End_Date;
    }

    public void setEnd_Date(String end_Date) {
        End_Date = end_Date;
    }

    public String getStart_Time() {
        return Start_Time;
    }

    public void setStart_Time(String start_Time) {
        Start_Time = start_Time;
    }

    public String getEnd_Time() {
        return End_Time;
    }

    public void setEnd_Time(String end_Time) {
        End_Time = end_Time;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String country) {
        Country = country;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getDistrict() {
        return District;
    }

    public void setDistrict(String district) {
        District = district;
    }

    public String getStreet_Address() {
        return Street_Address;
    }

    public void setStreet_Address(String street_Address) {
        Street_Address = street_Address;
    }

    public int getEventID() {
        return eventID;
    }

    public void setEventID(int eventID) {
        this.eventID = eventID;
    }

    public int getT_Person_Detail_Id() {
        return T_Person_Detail_Id;
    }

    public void setT_Person_Detail_Id(int t_Person_Detail_Id) {
        T_Person_Detail_Id = t_Person_Detail_Id;
    }
}
