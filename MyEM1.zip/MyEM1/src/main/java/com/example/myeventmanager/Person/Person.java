package com.example.myeventmanager.Person;

public class Person {

    public int Tbl_Person_Detail_Id;
    public String Person_First_Name;
    public String Person_Last_Name;
    public String Date_Of_Birth;
    public String Gender;
    public String Address;
    public String Email_Id;
    public String Phone_Number;
    public String Username;
    public String Password;
    public String Degree;
    public String Institute_Name;
    public String Board_University;
    public String Grade_Division;
    public String Passing_Year;
    public String Professional_Qualification;
    public String Working_Company_Job;

    public int getTbl_Person_Detail_Id() {
        return Tbl_Person_Detail_Id;
    }

    public void setTbl_Person_Detail_Id(int tbl_Person_Detail_Id) {
        Tbl_Person_Detail_Id = tbl_Person_Detail_Id;
    }

    public String getPerson_First_Name() {
        return Person_First_Name;
    }

    public void setPerson_First_Name(String person_First_Name) {
        Person_First_Name = person_First_Name;
    }

    public String getPerson_Last_Name() {
        return Person_Last_Name;
    }

    public void setPerson_Last_Name(String person_Last_Name) {
        Person_Last_Name = person_Last_Name;
    }

    public String getDate_Of_Birth() {
        return Date_Of_Birth;
    }

    public void setDate_Of_Birth(String date_Of_Birth) {
        Date_Of_Birth = date_Of_Birth;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getEmail_Id() {
        return Email_Id;
    }

    public void setEmail_Id(String email_Id) {
        Email_Id = email_Id;
    }

    public String getPhone_Number() {
        return Phone_Number;
    }

    public void setPhone_Number(String phone_Number) {
        Phone_Number = phone_Number;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getDegree() {
        return Degree;
    }

    public void setDegree(String degree) {
        Degree = degree;
    }

    public String getInstitute_Name() {
        return Institute_Name;
    }

    public void setInstitute_Name(String institute_Name) {
        Institute_Name = institute_Name;
    }

    public String getBoard_University() {
        return Board_University;
    }

    public void setBoard_University(String board_University) {
        Board_University = board_University;
    }

    public String getGrade_Division() {
        return Grade_Division;
    }

    public void setGrade_Division(String grade_Division) {
        Grade_Division = grade_Division;
    }

    public String getPassing_Year() {
        return Passing_Year;
    }

    public void setPassing_Year(String passing_Year) {
        Passing_Year = passing_Year;
    }

    public String getProfessional_Qualification() {
        return Professional_Qualification;
    }

    public void setProfessional_Qualification(String professional_Qualification) {
        Professional_Qualification = professional_Qualification;
    }

    public String getWorking_Company_Job() {
        return Working_Company_Job;
    }

    public void setWorking_Company_Job(String working_Company_Job) {
        Working_Company_Job = working_Company_Job;
    }
}
