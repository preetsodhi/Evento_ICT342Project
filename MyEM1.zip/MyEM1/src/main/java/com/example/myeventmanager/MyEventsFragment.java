package com.example.myeventmanager;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myeventmanager.Event.Event;
import com.example.myeventmanager.Event.EventAdapter;
import com.example.myeventmanager.Prevalent.prevalent;
import com.example.myeventmanager.Service.Caller;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import io.paperdb.Paper;

import static java.lang.Integer.parseInt;

public class MyEventsFragment extends Fragment  {

    private RecyclerView recyclerView;
    private EventAdapter adapter;
    private List<Event> eventList = new ArrayList<>();
    private FloatingActionButton fab;
    private AddNewEventListener listener;
    Caller c;
    String PersonID;

    String method;
    public static String rslt="";

    public MyEventsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        listener = (AddNewEventListener) context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_myevents, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.recyclerview);
        fab = view.findViewById(R.id.fab);
        c = new Caller();
        PersonID = Paper.book().read(prevalent.UserPersonID);
        int r = getAllEvents();

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onAddNewEvent();
            }
        });
    }

    public interface AddNewEventListener{
        void onAddNewEvent();
        void onComplete();
    }
    private int getAllEvents() {
        try {
            rslt = "START";
            method = "GetAllEvents";

            c.personID = parseInt(PersonID);
            c.method = method;
            c.join();
            c.start();
            while (rslt == "START") {
                try {
                    Thread.sleep(10);
                } catch (Exception ex) {
                    Toast.makeText(getContext(), "Error " + ex.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception ex) {
            //ad.setTitle("Error!"); ad.setMessage(ex.toString());
        }
        if (rslt.equals("Success")) {
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
            linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
            GridLayoutManager glm = new GridLayoutManager(getActivity(), 2);
            recyclerView.setLayoutManager(glm);
            adapter = new EventAdapter(getActivity(), Arrays.asList(c.eDTO));
            recyclerView.setAdapter(adapter);

            return 1;
        } else if(rslt.equals("NoEvents")){
            return  0;
        }
        return 0;
    }
}
