package com.example.myeventmanager.Service;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

public class CallSoap {

    public String SOAP_ACTION ="";

    public String OPERATION_NAME ="";

    public  final String WSDL_TARGET_NAMESPACE = "http://tempuri.org/";

    public  final String SOAP_ADDRESS = "http://49.205.180.195/AndroidAppService/AndroidWebService.asmx";
    public CallSoap(String OPERATION_NAME)
    {

        this.OPERATION_NAME = OPERATION_NAME;
    }

    public String CallSignUp(String PersonFirstName,String PersonLastName,String phoneNo,String Email,String Dob,
                             String Gender,String address,String Username,String password, String Company)
    {
        SOAP_ACTION = WSDL_TARGET_NAMESPACE + OPERATION_NAME;

        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        PropertyInfo pi=new PropertyInfo();
        pi.setName("PersonFirstName");
        pi.setValue(PersonFirstName);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("PersonLastName");
        pi.setValue(PersonLastName);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("phoneNo");
        pi.setValue(phoneNo);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("Email");
        pi.setValue(Email);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("Dob");
        pi.setValue(Dob);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("Gender");
        pi.setValue(Gender);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("address");
        pi.setValue(address);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("Username");
        pi.setValue(Username);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("password");
        pi.setValue(password);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("Company");
        pi.setValue(Company);
        pi.setType(String.class);
        request.addProperty(pi);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.dotNet = true;
        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS,3000);
        httpTransport.debug = true;
        String response="";
        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse().toString();
        }
        catch (Exception exception)
        {
            response=exception.toString();
        }
        return response;
    }
    public String CallLogin(String phoneNo,String Password)
    {
        SOAP_ACTION = WSDL_TARGET_NAMESPACE + OPERATION_NAME;

        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        PropertyInfo pi=new PropertyInfo();

        pi.setName("Phone_Number");
        pi.setValue(phoneNo);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("Password");
        pi.setValue(Password);
        pi.setType(String.class);
        request.addProperty(pi);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.dotNet = true;
        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS,3000);
        httpTransport.debug = true;
        String response="";
        int resp;
        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse().toString();
        }
        catch (Exception exception)
        {
            response=exception.toString();
        }
        return response;
    }
    public String CallAddEvent(String name,String title,int eventCategoryID, String description,
                                 String startDate,String endDate,String startTime, String endTime,
                                 String locationCountry, String locationCity, String locationDistrict,String locationStreet,int PersonID)
    {
        SOAP_ACTION = WSDL_TARGET_NAMESPACE + OPERATION_NAME;

        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        PropertyInfo pi=new PropertyInfo();
        pi.setName("Name");
        pi.setValue(name);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("Title");
        pi.setValue(title);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("EventCategoryID");
        pi.setValue(eventCategoryID);
        pi.setType(Integer.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("Description");
        pi.setValue(description);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("StartDate");
        pi.setValue(startDate);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("EndDate");
        pi.setValue(endDate);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("StartTime");
        pi.setValue(startTime);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("EndTime");
        pi.setValue(endTime);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("LocationCountry");
        pi.setValue(locationCountry);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("LocationDistrict");
        pi.setValue(locationDistrict);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("LocationCity");
        pi.setValue(locationCity);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("LocationStreet");
        pi.setValue(locationStreet);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("PersonID");
        pi.setValue(PersonID);
        pi.setType(Integer.class);
        request.addProperty(pi);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.dotNet = true;
        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS);
        httpTransport.debug = true;
        String response="";
        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse().toString();
        }
        catch (Exception exception)
        {
            response=exception.toString();
        }
        return response;
    }
    public String CallUpdateEvent(int eventID,String name,String title,int eventCategoryID, String description,
                                    String startDate,String endDate,String startTime, String endTime,
                                    String locationCountry, String locationCity, String locationDistrict,String locationStreet,int personid)
    {
        SOAP_ACTION = WSDL_TARGET_NAMESPACE + OPERATION_NAME;

        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        PropertyInfo pi=new PropertyInfo();

        pi.setName("T_Event_Id");
        pi.setValue(eventID);
        pi.setType(Integer.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("Name");
        pi.setValue(name);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("Title");
        pi.setValue(title);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("EventCategoryID");
        pi.setValue(eventCategoryID);
        pi.setType(Integer.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("Description");
        pi.setValue(description);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("StartDate");
        pi.setValue(startDate);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("EndDate");
        pi.setValue(endDate);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("StartTime");
        pi.setValue(startTime);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("EndTime");
        pi.setValue(endTime);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("LocationCountry");
        pi.setValue(locationCountry);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("LocationDistrict");
        pi.setValue(locationDistrict);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("LocationCity");
        pi.setValue(locationCity);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("LocationStreet");
        pi.setValue(locationStreet);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("PersonID");
        pi.setValue(personid);
        pi.setType(Integer.class);
        request.addProperty(pi);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.dotNet = true;
        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS);
        httpTransport.debug = true;
        String response="";
        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse().toString();
        }
        catch (Exception exception)
        {
            response=exception.toString();
        }
        return response;
    }
    public String CallGetAllEvents(int Person_ID)
    {
        SOAP_ACTION = WSDL_TARGET_NAMESPACE + OPERATION_NAME;

        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        PropertyInfo pi=new PropertyInfo();

        pi.setName("T_Person_Detail_Id");
        pi.setValue(Person_ID);
        pi.setType(Integer.class);
        request.addProperty(pi);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.dotNet = true;
        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS,3000);
        httpTransport.debug = true;
        String response;
        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse().toString();

        }
        catch (Exception exception)
        {
            response=exception.toString();
        }
        return response;
    }    public String CallAddMeeting(String name,String title,int meetingTypeID, String description,
                                 String startDate,String endDate,String startTime, String endTime,
                                 String locationCountry, String locationCity, String locationDistrict,String locationStreet,int PersonID)
    {
        SOAP_ACTION = WSDL_TARGET_NAMESPACE + OPERATION_NAME;

        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        PropertyInfo pi=new PropertyInfo();
        pi.setName("name");
        pi.setValue(name);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("title");
        pi.setValue(title);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("M_meetingtype_id");
        pi.setValue(meetingTypeID);
        pi.setType(Integer.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("description");
        pi.setValue(description);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("startDate");
        pi.setValue(startDate);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("endDate");
        pi.setValue(endDate);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("startTime");
        pi.setValue(startTime);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("endTime");
        pi.setValue(endTime);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("locationCountry");
        pi.setValue(locationCountry);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("locationDistrict");
        pi.setValue(locationDistrict);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("locationCity");
        pi.setValue(locationCity);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("locationStreet");
        pi.setValue(locationStreet);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("personid");
        pi.setValue(PersonID);
        pi.setType(Integer.class);
        request.addProperty(pi);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.dotNet = true;
        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS);
        httpTransport.debug = true;
        String response="";
        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse().toString();
        }
        catch (Exception exception)
        {
            response=exception.toString();
        }
        return response;
    }
    public String CallUpdateMeeting(int meetingID,String name,String title,int meetingTypeID, String description,
                                 String startDate,String endDate,String startTime, String endTime,
                                 String locationCountry, String locationCity, String locationDistrict,String locationStreet,int PersonID)
    {
        SOAP_ACTION = WSDL_TARGET_NAMESPACE + OPERATION_NAME;

        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        PropertyInfo pi=new PropertyInfo();

        pi.setName("T_Meeting_Id");
        pi.setValue(meetingID);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("name");
        pi.setValue(name);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("title");
        pi.setValue(title);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("M_meetingtype_id");
        pi.setValue(meetingTypeID);
        pi.setType(Integer.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("description");
        pi.setValue(description);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("startDate");
        pi.setValue(startDate);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("endDate");
        pi.setValue(endDate);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("startTime");
        pi.setValue(startTime);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("endTime");
        pi.setValue(endTime);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("locationCountry");
        pi.setValue(locationCountry);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("locationDistrict");
        pi.setValue(locationDistrict);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("locationCity");
        pi.setValue(locationCity);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("locationStreet");
        pi.setValue(locationStreet);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("personid");
        pi.setValue(PersonID);
        pi.setType(Integer.class);
        request.addProperty(pi);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.dotNet = true;
        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS);
        httpTransport.debug = true;
        httpTransport.debug = true;
        String response="";
        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse().toString();
        }
        catch (Exception exception)
        {
            response=exception.toString();
        }
        return response;
    }
    public String CallGetAllMeeting(int Person_ID)
    {
        SOAP_ACTION = WSDL_TARGET_NAMESPACE + OPERATION_NAME;

        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        PropertyInfo pi=new PropertyInfo();

        pi.setName("T_Person_Detail_Id");
        pi.setValue(Person_ID);
        pi.setType(Integer.class);
        request.addProperty(pi);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.dotNet = true;
        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS,3000);
        httpTransport.debug = true;
        String response ="";
        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse().toString();

        }
        catch (Exception exception)
        {
            response=exception.toString();
        }
        return response;
    }
    public String CallDeleteMeeting(int Meeting_Id)
    {
        SOAP_ACTION = WSDL_TARGET_NAMESPACE + OPERATION_NAME;

        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        PropertyInfo pi=new PropertyInfo();

        pi.setName("T_Meeting_Id");
        pi.setValue(Meeting_Id);
        pi.setType(Integer.class);
        request.addProperty(pi);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.dotNet = true;
        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS,3000);
        httpTransport.debug = true;
        String response ="";
        SoapObject r;
        int a;
        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse().toString();

        }
        catch (Exception exception)
        {
            response=exception.toString();
        }
        return response;
    }
    public String CallDeleteEvent(int Event_Id)
    {
        SOAP_ACTION = WSDL_TARGET_NAMESPACE + OPERATION_NAME;

        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        PropertyInfo pi=new PropertyInfo();

        pi.setName("T_Event_Id");
        pi.setValue(Event_Id);
        pi.setType(Integer.class);
        request.addProperty(pi);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.dotNet = true;
        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS,3000);
        httpTransport.debug = true;
        String response ="";
        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse().toString();

        }
        catch (Exception exception)
        {
            response=exception.toString();
        }
        return response;
    }
    public String CallGetMeetingById(int Meeting_Id)
    {
        SOAP_ACTION = WSDL_TARGET_NAMESPACE + OPERATION_NAME;

        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        PropertyInfo pi=new PropertyInfo();
        pi.setName("T_Meeting_Id");
        pi.setValue(Meeting_Id);
        pi.setType(Integer.class);
        request.addProperty(pi);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.dotNet = true;
        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS,3000);
        httpTransport.debug = true;
        String response ="";
        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse().toString();
        }
        catch (Exception exception)
        {
            response=exception.toString();
        }
        return response;
    }
    public String CallGetEventById(int Event_Id)
    {
        SOAP_ACTION = WSDL_TARGET_NAMESPACE + OPERATION_NAME;

        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        PropertyInfo pi=new PropertyInfo();
        pi.setName("T_Event_Id");
        pi.setValue(Event_Id);
        pi.setType(Integer.class);
        request.addProperty(pi);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.dotNet = true;
        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS,3000);
        httpTransport.debug = true;
        String response ="";
        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse().toString();

        }
        catch (Exception exception)
        {
            response=exception.toString();
        }
        return response;
    }
    public String CallGetAllUpcomingEvents()
    {
        SOAP_ACTION = WSDL_TARGET_NAMESPACE + OPERATION_NAME;

        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.dotNet = true;
        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS,3000);
        httpTransport.debug = true;
        String response ="";
        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse().toString();

        }
        catch (Exception exception)
        {
            response=exception.toString();
        }
        return response;
    }
    public String CallPersonUpdate(int PersonID)
    {
        SOAP_ACTION = WSDL_TARGET_NAMESPACE + OPERATION_NAME;

        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        PropertyInfo pi=new PropertyInfo();

        pi.setName("Person_ID");
        pi.setValue(PersonID);
        pi.setType(String.class);
        request.addProperty(pi);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.dotNet = true;
        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS,3000);
        httpTransport.debug = true;
        String response="";
        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse().toString();
        }
        catch (Exception exception)
        {
            response=exception.toString();
        }
        return response;
    }
    public String Callforgotpassword(String phoneNo, String password)
    {
        SOAP_ACTION = WSDL_TARGET_NAMESPACE + OPERATION_NAME;

        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        PropertyInfo pi=new PropertyInfo();

        pi.setName("Phone_Number");
        pi.setValue(phoneNo);
        pi.setType(String.class);
        request.addProperty(pi);
        pi=new PropertyInfo();
        pi.setName("Password");
        pi.setValue(password);
        pi.setType(String.class);
        request.addProperty(pi);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.dotNet = true;
        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS,3000);
        httpTransport.debug = true;
        String response="";
        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse().toString();
        }
        catch (Exception exception)
        {
            response=exception.toString();
        }
        return response;
    }
}
