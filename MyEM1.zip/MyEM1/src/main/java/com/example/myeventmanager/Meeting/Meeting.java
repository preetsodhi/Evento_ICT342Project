package com.example.myeventmanager.Meeting;

import com.example.myeventmanager.R;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class Meeting {

    @SerializedName("Meeting_Name")
    private String Meeting_Name;
    @SerializedName("Meeting_Title")
    private String Meeting_Title;
    @SerializedName("Meeting_Category")
    private String Meeting_Category;
    @SerializedName("Meeting_Description")
    private String Meeting_Description;
    @SerializedName("Start_Date")
    private String Start_Date;
    @SerializedName("End_Date")
    private String End_Date;
    @SerializedName("Start_Time")
    private String Start_Time;
    @SerializedName("End_Time")
    private String End_Time;
    @SerializedName("Country")
    private String Country;
    @SerializedName("City")
    private String City;
    @SerializedName("District")
    private String District;
    @SerializedName("Street_Address")
    private String Street_Address;
    @SerializedName("T_Meeting_Id")
    private int meetingID;
    public int T_Person_Detail_Id;


    public Meeting(){}

    public Meeting(int meetingID, String meetingName,String meetingTitle, String meetingCategory,String meetingDescription,
                 String meetingStartDate,String meetingEndDate,String meetingStartTime,
                 String meetingEndTime,String meetingLocationCountry, String meetingLocationCity,
                           String meetingLocationDistrict, String meetingLocationStreetAddress) {
        this.meetingID = meetingID;
        this.Meeting_Name = meetingName;
        this.Meeting_Title = meetingTitle;
        this.Meeting_Category = meetingCategory;
        this.Meeting_Description = meetingDescription;
        this.Start_Date = meetingStartDate;
        this.End_Date = meetingEndDate;
        this.Start_Time = meetingStartTime;
        this.End_Time = meetingEndTime;
        this.Country = meetingLocationCountry;
        this.City = meetingLocationCity;
        this.District = meetingLocationDistrict;
        this.Street_Address = meetingLocationStreetAddress;

    }

    public Meeting(String  meetingName,String meetingTitle, String meetingCategory,String meetingDescription,
                 String meetingStartDate,String meetingEndDate,String meetingStartTime,
                 String meetingEndTime,String meetingLocationCountry, String meetingLocationCity,
                   String meetingLocationDistrict, String meetingLocationStreetAddress) {
        this.Meeting_Name = meetingName;
        this.Meeting_Title = meetingTitle;
        this.Meeting_Category = meetingCategory;
        this.Meeting_Description = meetingDescription;
        this.Start_Date = meetingStartDate;
        this.End_Date = meetingEndDate;
        this.Start_Time = meetingStartTime;
        this.End_Time = meetingEndTime;
        this.Country = meetingLocationCountry;
        this.City = meetingLocationCity;
        this.District = meetingLocationDistrict;
        this.Street_Address = meetingLocationStreetAddress;
    }




    public static List<Meeting> generateMeetingList(){
        List<Meeting> meetingList = new ArrayList<>();
        meetingList.add(new Meeting(R.drawable.convocation, "Convocation","", "versity", "Banani", "08/05/2019","",""
                ,"","","","",""));
        meetingList.add(new Meeting(R.drawable.festival, "Festival","","","","","", "festival", "Bashundhara", "21/03/2018"
        ,"","",""));
        meetingList.add(new Meeting(R.drawable.job_fair, "Job Fair", "carrer", "Dhanmondi", "12/06/2019","","","","",""
                ,"","",""));
        meetingList.add(new Meeting(R.drawable.math_olympiad, "Math Olympiad", "olympiad", "Karawn Bazar", "25/02/2017","","","","",""
                ,"","",""));
        meetingList.add(new Meeting(R.drawable.pro_contest, "Programming Contest", "programming", "Gulshan", "03/09/2016","","","","",""
                ,"","",""));
        meetingList.add(new Meeting(R.drawable.reunion, "Reunion", "versity", "Sahabag", "05/10/2013","","","","",""
                ,"","",""));
        meetingList.add(new Meeting(R.drawable.robotics, "Robotics Contest", "robotics", "Baridhara", "31/03/2019","","","","",""
                ,"","",""));
        meetingList.add(new Meeting(R.drawable.science_olympiad, "Science Olympiad", "olympiad", "Panthopath", "07/12/2015","","","","",""
                ,"","",""));
        return meetingList;
    }

    public int getMeetingID() {
        return meetingID;
    }

    public String getMeetingName() {
        return Meeting_Name;
    }

    public String getMeetingTitle() {
        return Meeting_Title;
    }

    public String getMeetingCategory() {
        return Meeting_Category;
    }

    public String getMeetingDescription() {
        return Meeting_Description;
    }

    public String getMeetingStartDate() {
        return Start_Date;
    }

    public String getMeetingEndDate() {
        return End_Date;
    }

    public String getMeetingStartTime() {
        return Start_Time;
    }

    public String getMeetingEndTime() {
        return End_Time;
    }

    public String getMeetingLocationCountry() {
        return Country;
    }

    public String getMeetingLocationCity() {
        return City;
    }

    public String getMeetingLocationDistrict() {
        return District;
    }

    public String getMeetingLocationStreetAddress() {
        return Street_Address;
    }
}
