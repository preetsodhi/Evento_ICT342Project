package com.example.myeventmanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myeventmanager.Prevalent.prevalent;
import com.example.myeventmanager.Service.Caller;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;


public class ResetPasswordActivity extends AppCompatActivity {

    private EditText MobNo, otp,password1, password2;
    private Button btn_sendOTP, btn_setNewPassword,btn_verifyOTP;

    private ProgressDialog loadingBar;

    String mobNo,pass1,pass2;

    FirebaseAuth auth;
    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallback;
    String verificationCode;

    String method;
    public static String rslt="";
    public static String rslt2 = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        MobNo = (EditText)findViewById(R.id.reset_phoneno);
        otp = (EditText)findViewById(R.id.otp);
        password1 = (EditText)findViewById(R.id.reset_password);
        password2 = (EditText)findViewById(R.id.reset_repassword);
        btn_sendOTP = (Button) findViewById(R.id.reset_btn_verify);
        btn_setNewPassword = (Button)findViewById(R.id.reset_btn_setPassword);
        btn_verifyOTP = (Button)findViewById(R.id.reset_btn_otpverify) ;

        auth = FirebaseAuth.getInstance();
        loadingBar = new ProgressDialog(this);

        mCallback = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            @Override
            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {

            }

            @Override
            public void onVerificationFailed(@NonNull FirebaseException e) {

            }

            @Override
            public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                super.onCodeSent(s, forceResendingToken);
                verificationCode = s;
                Toast.makeText(ResetPasswordActivity.this,"Code sent to your number!!",Toast.LENGTH_SHORT).show();
            }
        };

        btn_sendOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ResetPassword();

            }
        });
    }
    public void ResetPassword(){
       mobNo = MobNo.getText().toString();
       if (mobNo.isEmpty())
           Toast.makeText(ResetPasswordActivity.this,"Please Enter Mobile No. with Country Code..!!!",Toast.LENGTH_SHORT).show();
       else {
           MobNo.setVisibility(View.INVISIBLE);
           btn_sendOTP.setVisibility(View.INVISIBLE);
           otp.setVisibility(View.VISIBLE);
           btn_verifyOTP.setVisibility(View.VISIBLE);

           PhoneAuthProvider.getInstance().verifyPhoneNumber(
                   mobNo,60, TimeUnit.SECONDS,this,mCallback
           );

       }
    }

    public void verify(View v) {
        String inputcode = otp.getText().toString();
        if (inputcode.equals(""))
            Toast.makeText(ResetPasswordActivity.this, "Please enter OTP received", Toast.LENGTH_SHORT).show();
        else {

            verifyPhoneNumber(verificationCode, inputcode);
        }
    }
    public void verifyPhoneNumber(String verificationCode, String inputcode) {
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationCode,inputcode);
        signInWithPhone(credential);
    }
    private void signInWithPhone(PhoneAuthCredential credential) {
        auth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()) {
                            otp.setVisibility(View.INVISIBLE);
                            btn_verifyOTP.setVisibility(View.INVISIBLE);
                            password1.setVisibility(View.VISIBLE);
                            password2.setVisibility(View.VISIBLE);
                            btn_setNewPassword.setVisibility(View.VISIBLE);

                        }
                    }
                });
    }

    public void setNewPassword(View view){
        pass1 = password1.getText().toString();
        pass2 = password2.getText().toString();
        if(pass1.isEmpty())
            Toast.makeText(ResetPasswordActivity.this, "Please Enter Password", Toast.LENGTH_SHORT).show();
        if(pass2.isEmpty())
            Toast.makeText(ResetPasswordActivity.this, "Please ReEnter Password", Toast.LENGTH_SHORT).show();
        if(!(pass1.equals(pass2)))
            Toast.makeText(ResetPasswordActivity.this, "Passwords do not match..!! Enter Same Passwords", Toast.LENGTH_SHORT).show();
        else {
            loadingBar.setTitle("Setting New Password");
            loadingBar.setMessage("Please wait while we are checking the credentials.");
            loadingBar.setCanceledOnTouchOutside(false);
            loadingBar.show();
            validate(mobNo,pass1);
        }
    }

    private void validate(final String phoneno, final String pass) {

        /*final DatabaseReference RootRef;
        RootRef = FirebaseDatabase.getInstance().getReference();

        RootRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if((dataSnapshot.child("Users").child(phoneno).exists()))
                {
                    RootRef.child("Users").child(phoneno).child("password").setValue(pass);

                   Toast.makeText(ResetPasswordActivity.this,"Congratulations!! New Password Has Been Set Up..!!",Toast.LENGTH_SHORT).show();
                    loadingBar.dismiss();
                    Intent intent = new Intent(ResetPasswordActivity.this,LoginActivity.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(ResetPasswordActivity.this,"This "+phoneno+" does not exists.. Create new account.",Toast.LENGTH_LONG).show();
                    loadingBar.dismiss();
                    Intent i = new Intent(ResetPasswordActivity.this, RegisterActivity.class);
                    startActivity(i);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
         */

        try {
            rslt = "START";
            method = "forgotpassword";
            Caller c = new Caller();

            c.phoneNo = phoneno;
            c.password = pass;
            c.method = method;

            c.join(); c.start();
            while (rslt == "START") {
                try {
                    Thread.sleep(10);
                } catch (Exception ex) {
                    Toast.makeText(getApplicationContext(), "Error " + ex.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception ex) {
            //ad.setTitle("Error!"); ad.setMessage(ex.toString());
        }
        if (rslt.equals("0")) {
            loadingBar.dismiss();
            Toast.makeText(getApplicationContext(), "Congratulations!! New Password Has Been Set Up..!!!", Toast.LENGTH_LONG).show();
            Intent i = new Intent(ResetPasswordActivity.this,LoginActivity.class);
            startActivity(i);
        } else {
            loadingBar.dismiss();
            Toast.makeText(getApplicationContext(), "Account With This Mobile Number Does Not Exist...!!!", Toast.LENGTH_LONG).show();
        }

    }

}
