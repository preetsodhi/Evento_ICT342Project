package com.example.myeventmanager.Event;

import com.example.myeventmanager.R;

import java.util.ArrayList;
import java.util.List;

public class Event {
    private int eventID;
    private String eventName;
    private String eventTitle;
    private String eventCategory;
    private String eventDescription;
    private String eventStartDate;
    private String eventEndDate;
    private String eventStartTime;
    private String eventEndTime;
    private String eventLocationCountry;
    private String eventLocationCity;
    private String eventLocationDistrict;
    private String eventLocationStreetAddress;

    public Event(int eventID, String eventName,String eventTitle, String eventCategory,String eventDescription,
                 String eventStartDate,String eventEndDate,String eventStartTime,
                 String eventEndTime,String eventLocationCountry,String eventLocationCity,
                 String eventLocationDistrict, String eventLocationStreetAddress) {
        this.eventID = eventID;
        this.eventName = eventName;
        this.eventTitle = eventTitle;
        this.eventCategory = eventCategory;
        this.eventDescription = eventDescription;
        this.eventStartDate = eventStartDate;
        this.eventEndDate = eventEndDate;
        this.eventStartTime = eventStartTime;
        this.eventEndTime = eventEndTime;
        this.eventLocationCountry = eventLocationCountry;
        this.eventLocationCity = eventLocationCity;
        this.eventLocationDistrict = eventLocationDistrict;
        this.eventLocationStreetAddress = eventLocationStreetAddress;

    }
    public Event(){}

    public Event(String eventName,String eventTitle, String eventCategory,String eventDescription,
                 String eventStartDate,String eventEndDate,String eventStartTime,
                 String eventEndTime,String eventLocationCountry, String eventLocationCity,
                 String eventLocationDistrict, String eventLocationStreetAddress) {
        this.eventName = eventName;
        this.eventTitle = eventTitle;
        this.eventCategory = eventCategory;
        this.eventDescription = eventDescription;
        this.eventStartDate = eventStartDate;
        this.eventEndDate = eventEndDate;
        this.eventStartTime = eventStartTime;
        this.eventEndTime = eventEndTime;
        this.eventLocationCountry = eventLocationCountry;
        this.eventLocationCity = eventLocationCity;
        this.eventLocationDistrict = eventLocationDistrict;
        this.eventLocationStreetAddress = eventLocationStreetAddress;
    }

    public int getEventID() {
        return eventID;
    }

    public String getEventName() {
        return eventName;
    }

    public String getEventTitle() {
        return eventTitle;
    }

    public String getEventCategory() {
        return eventCategory;
    }

    public String getEventDescription() {
        return eventDescription;
    }

    public String getEventStartDate() {
        return eventStartDate;
    }

    public String getEventEndDate() {
        return eventEndDate;
    }

    public String getEventStartTime() {
        return eventStartTime;
    }

    public String getEventEndTime() {
        return eventEndTime;
    }

    public String getEventLocationCountry() {
        return eventLocationCountry;
    }

    public String getEventLocationCity() {
        return eventLocationCity;
    }

    public String getEventLocationDistrict() {
        return eventLocationDistrict;
    }

    public String getEventLocationStreetAddress() {
        return eventLocationStreetAddress;
    }

    public static List<Event> generateEventList(){
        List<Event> eventList = new ArrayList<>();
        eventList.add(new Event(R.drawable.convocation, "Convocation","", "versity", "Banani", "08/05/2019","","","",
                "","","",""));
        eventList.add(new Event(R.drawable.festival, "Festival","","","","","", "festival", "Bashundhara", "21/03/2018"
                ,"","",""));
        eventList.add(new Event(R.drawable.job_fair, "Job Fair", "carrer", "Dhanmondi", "12/06/2019","","","","",""
                ,"","",""));
        eventList.add(new Event(R.drawable.math_olympiad, "Math Olympiad", "olympiad", "Karawn Bazar", "25/02/2017","",""
                ,"","","","","",""));
        eventList.add(new Event(R.drawable.pro_contest, "Programming Contest", "programming", "Gulshan", "03/09/2016",""
                ,"","","","","","",""));
        eventList.add(new Event(R.drawable.reunion, "Reunion", "versity", "Sahabag", "05/10/2013",""
                ,"","","","","","",""));
        eventList.add(new Event(R.drawable.robotics, "Robotics Contest", "robotics", "Baridhara", "31/03/2019","","","", "","","","",""));
        eventList.add(new Event(R.drawable.science_olympiad, "Science Olympiad", "olympiad", "Panthopath", "07/12/2015","","",""
                ,"","","","",""));
        return eventList;
    }
}

