package com.example.myeventmanager.Event;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;

import com.example.myeventmanager.R;
import com.example.myeventmanager.Service.Caller;

import java.util.ArrayList;
import java.util.List;

public class ShareEvent extends FragmentActivity {

    EditText msg, num;
    Button btn_send;
    int eventId;

    public static String rslt = "";
    String method;
    Caller c;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.share_event);
        c = new Caller();
        msg = (EditText) findViewById(R.id.messageED);
        num = (EditText) findViewById(R.id.numberED);
        btn_send = (Button) findViewById(R.id.send_btn);
        Bundle extras = getIntent().getExtras();
        eventId = extras.getInt("eventid");

        try {
            rslt="START";
            method="GetEventbyEventId";

            c.eventID = eventId;
            c.method = method;

            c.join(); c.start();
            while(rslt=="START") {
                try {
                    Thread.sleep(10);
                }catch(Exception ex) {
                    Toast.makeText(getApplicationContext(), "Error"+ex.toString(), Toast.LENGTH_SHORT).show();
                }
            }

        }catch(Exception ex) {
            //ad.setTitle("Error!"); ad.setMessage(ex.toString());
        }
        //ad.show();
        if(rslt.equals("Success")) {
            int a  = 0;
        }
        else {
            Toast.makeText(getApplicationContext(), "OOOPSSS....!! Something Went Wrong.. ", Toast.LENGTH_SHORT).show();
        }

        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msgg = msg.getText().toString();
                String numm = num.getText().toString();
                String eventName = c.name;
                String eventTitle = c.title;
                String eventCategory = c.category;
                String eventDescription = c.description;
                String eventStartDate = c.startDate;
                String eventEndDate = c.endDate;
                String eventStartTime = c.startTime;
                String eventEndTime = c.endTime;
                String eventStreet = c.locationStreet;
                String eventCity = c.locationCity;
                String eventDistrict = c.locationDistrict;
                String eventCountry = c.locationCountry;

                boolean installed = appInstalledOrNot("com.whatsapp");

                if(installed){
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("http://api.whatsapp.com/send?phone="+numm+"&text="+msgg+
                            "\n\nEvent Details:"+
                            "\nName: "+eventName+"\nTitle: "+eventTitle+"\nCategory: "+eventCategory+"\nDescription: "+eventDescription+
                            "\nStart Date: "+eventStartDate+"\nEnd Date: "+eventEndDate+
                            "\nStart Time: "+eventStartTime+"\nEnd Time: "+eventEndTime+
                            "\nAddress: "+eventStreet+", "+eventCity+", "+eventDistrict+", "+eventCountry));
                    startActivity(intent);
                }
                else {
                    Toast.makeText(ShareEvent.this,"WhatsApp not installed on your device",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public boolean appInstalledOrNot(String url){
        PackageManager packageManager = getPackageManager();
        boolean app_installed;
        try{
            packageManager.getPackageInfo(url,PackageManager.GET_ACTIVITIES);
            app_installed = true;

        }catch (PackageManager.NameNotFoundException e){
            app_installed = false;
        }
        return  app_installed;
    }
}

